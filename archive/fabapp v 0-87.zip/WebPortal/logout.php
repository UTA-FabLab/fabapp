<?php
session_start();
unset($_SESSION["user_name"]);
session_unset();
header("Location:index.php");
?>