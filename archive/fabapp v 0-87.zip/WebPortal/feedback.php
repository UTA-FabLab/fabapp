<?php 
require_once("connections/db_connect8.php");
session_start();
date_default_timezone_set('America/Chicago');

if (array_key_exists('submit',$_POST)) {
	echo 'Clicked';
	$to = 'jonathan.le2@mavs.uta.edu';
	$subject = 'FabApp Feedback';
	//message
	$message = 'From: '.$_POST['name']."\n\n";
	$message .= 'Ticket: '.$_POST['ticket']."\n\n";
	$message .= 'Comments: '.$_POST['message'];
	
	mail($to, $subject, $message);
}
?>
<html>
<head>
<link rel="shortcut icon" href="images/fa-icon.png" type="image/png">
	<title>Feedback</title>
	<link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<body>
	<?php include 'header.php';?>
	<table border="0" cellpadding="10" cellspacing="1" width="500" align="center">
		<form id="contactForm" name="contactForm" method="post" action="<?php $_SERVER['PHP_SELF']; ?>" autocomplete="off">
		<tr class="tableheader">
			<td align="center" colspan="2"><h1>Report a Problem</h1>
			<div class="header"></div>
			</td>
		</tr>
		<tr class="tablerow">
			<td align="right">Name</td>
			<td><input type="text" name="name" id="name"></td>
		</tr>
		<tr class="tablerow">
			<td align="right">Transaction</td>
			<td><input type="number" name="ticket" autocomplete="off" min="0" class="trans" autofocus></td>
		</tr>
		<tr class="tablerow">
			<td align="right">Message</td>
			<td><textarea name="message" id="message"></textarea></td>
		</tr>
		<tr class="tableheader">
		<td align="center" colspan="2"><input type="submit" name="submit" value="Submit" id="submitBtn"></td>
		</tr>
		</form>
	</table>


<script type="text/javascript">
setTimeout(function(){window.location.reload(1)}, 301000);
</script>
</body>
</html>