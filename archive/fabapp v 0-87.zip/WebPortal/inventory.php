<?php 
//List inventory
mysqli->query("

SELECT mats_used.m_id, m_name, SUM(unit_used), COUNT(mu_id) as '#of Tickets'
FROM `mats_used`
LEFT JOIN materials
ON mats_used.m_id = materials.m_id
WHERE m_parent = 1
GROUP BY m_name

");
	
/* specific material

SELECT mu_id, mats_used.m_id, m_name, unit_used, status_id
FROM `mats_used`
LEFT JOIN materials
ON mats_used.m_id = materials.m_id
WHERE mats_used.m_id=38


# of tickets for the last period(30 days)
consumption of materials over that period


//tickets per hour
SELECT HOUR( t_start ) AS HOUR , COUNT( HOUR( t_start ) ) AS  '# Tickets', DAYOFWEEK( t_start ) AS 
DAY 
FROM transactions
WHERE  `t_start` 
BETWEEN  '2016-09-22'
AND  '2016-11-6'
GROUP BY DAY , HOUR

//Filament Used Last (Time Interval)
SELECT mats_used.m_id, m_name, SUM(unit_used), COUNT(mu_id) as '#of Tickets'
FROM `mats_used`
LEFT JOIN materials
ON mats_used.m_id = materials.m_id
WHERE m_parent = 1 AND status_id != 8 and status_id != 9 AND `date` 
BETWEEN  '2016-09-22'
AND  '2016-10-6'
GROUP BY m_name

//General Use Numbers
SELECT device_id, COUNT(trans_id), SUM(est_time)/3600 as Est, SUM(duration)/3600 as Duration, SUM(unit_used) as 'Unit Used', SUM(total) as Total FROM  `transactions` 
WHERE `t_start` 
BETWEEN  '2016-09-01'
AND  '2016-09-30'
GROUP BY device_id

//Correct Status IDs
UPDATE mats_used
LEFT JOIN transactions
ON mats_used.trans_id = transactions.trans_id
SET mats_used.status_id = transactions.status_id
WHERE mats_used.trans_id IS NOT NULL;

UPDATE mats_used
SET status_id = 8
WHERE notes = 'resupply' OR notes = 'Initial Entry';

UPDATE mats_used
SET status_id = 9
WHERE notes = 'correction' OR notes = 'Inv correction';


M_id
12 - other
48 - 

*/
?>