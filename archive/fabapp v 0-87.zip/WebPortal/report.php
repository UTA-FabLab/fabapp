<?php
require_once("connections/db_connect8.php");
session_start();
date_default_timezone_set('America/Chicago');
$message = "";
if(!isset($_SESSION["user_name"])) {
	header("Location:index.php");	
}
if($_SESSION["time"] < time()) {
	header("Location:logout.php");	
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	if(isset($_POST["shelf"]) && isset($_POST["addy"])){
		$shelf = $_POST["shelf"];
		$addy = $_POST["addy"];
		if (preg_match("/^\d{1}$/",$shelf) == 0) {
			$message = "Invalid Address";
		} elseif (preg_match("/^[A-I]{1}$/",$addy) == 0) {
			$message = "Invalid Address";
		} else {
			updateAddy($_SESSION["trans_id"], $shelf, $addy);
		}
	}
}
function updateAddy($trans_id, $shelf, $addy){
	global $message, $mysqli;
	$address = $shelf.$addy;
	
	if ($mysqli->query("
		UPDATE `objbox`
		SET `address` = '$address'
		WHERE `trans_id` = '$trans_id';
	")){
		$_SESSION["trans_id"] = $trans_id;
		$_SESSION["final_addy"] = $address;
		header("Location:report.php");
	} else {
		$message = $mysqli->error;
	}
}
?>
<html>
<head>
<link rel="shortcut icon" href="images/fa-icon.png?v=2" type="image/png">
	<title>FabLab Transaction #</title>
	<link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<body>
	<?php include 'header.php';?>
	<table border="0" cellpadding="10" cellspacing="1" width="500" align="center">
		<tr class="tableheader">
			<td align="center" colspan="2"><?php 
			if( isset($_SESSION["address"]) ){ ?>
				<form id="form" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" onsubmit="submitBtn.disabled = true; return true;">
				Move 3D Print
			<?php  } elseif( isset($_SESSION["final_addy"]) ) { ?>
				<form id="form" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" onsubmit="submitBtn.disabled = true; return true;">
				Move 3D Print
				<div class="message"><?php if($message!="") { echo $message; } ?></div>
			<?php  } else { ?>
				Ticket Created
				<div class="message"><?php if($message!="") { echo $message; } ?></div>
			<?php  } ?>
			</td>
		</tr>
		<tr class="tablerow">
			<td align="right">Ticket Number</td>
			<td align="center"><?php echo $_SESSION["trans_id"];?></td>
		</tr>
		<?php if(isset($_SESSION["address"])){ ?>
		<tr class="tablerow">
			<td align="right">Place on Shelf</td>
			<td align="center"><select name="shelf">
                	<option value="1" id="1">1</option>
                	<option value="2" id="2">2</option>
                	<option value="3" id="3">3</option>
                	<option value="4" id="4">4</option>
                	<option value="5" id="5">5</option>
                </select>
                <select name="addy">
             		<option value="A" id="A">A</option>
             		<option value="B" id="B">B</option>
             		<option value="C" id="C">C</option>
             		<option value="D" id="D">D</option>
             		<option value="E" id="E">E</option>
             		<option value="F" id="F">F</option>
             		<option value="G" id="G">G</option>
             		<option value="H" id="H">H</option>
             		<option value="I" id="I">I</option>
				</select>
			</td>
		</tr>
		<?php } ?>
		<?php if(isset($_SESSION["final_addy"])){ ?>
		<tr class="tablerow">
			<td align="right">Placed on Shelf</td>
			<td align="center"><?php echo($_SESSION["final_addy"]);?></td>
		</tr>
		<?php } ?>
		<tr class="tableheader"><?php 
		if(isset($_SESSION["address"])){ ?>
			<td align="center" ><a href="hom.php">Return</a></td>
			<td align="center" ><input type="submit" name="submit" value="Confirm Address" id="submitBtn"></td>
			</form>
		<?php } else { ?>
			<td align="center" colspan="2"><a href="home.php">Return</a></td>
		<?php } ?>
		</tr>
	</table>
<script type="text/javascript">
window.onload = function(){
	<?php $address = $_SESSION["address"]; 
	$shelf = substr($address, 0,1);
	$addy = substr($address, -1);
	unset($_SESSION["address"]);
	?>
	document.getElementById("<?php echo $shelf ?>").selected=true;
	document.getElementById("<?php echo $addy ?>").selected=true;
}
</script>
</body>
</html>