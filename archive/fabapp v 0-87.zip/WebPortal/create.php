<?php
require_once("connections/db_connect8.php");
require_once("site_variables.php");
session_start();
date_default_timezone_set('America/Chicago');
$utaErr = $deviceErr = $timeErr = $mErr = $purpErr = $time = $uta_id  = "";
$message = $weightErr = $hh = $mm = $volume1 = $volume2 = "";
$error = $loadError = false;

if(!isset($_SESSION["user_name"]) || $_SESSION["time"] < time()) {
	header("Location:logout.php");	
}

// Check Device ID
if (empty($_GET["device_id"])){
	header("Location:home.php");	
	$loadError = true;
} else {
	$device_id = $_GET["device_id"];
	if (preg_match("/^\d{4}$/",$device_id) == 0) {
		$deviceErr = "Bad device ID";	
		$loadError = true;
	} elseif($result = $mysqli->query("
		SELECT device_desc, dg_name, d_duration
		FROM devices
		JOIN device_group 
		ON devices.dg_id = device_group.dg_id
		WHERE device_id = $device_id
	")){
		if ($result->num_rows == 0){
			$message = "Device Not Found.";
			$loadError = true;
		} else {
			$row = $result->fetch_assoc();
			$device_desc = $row["device_desc"];
			$dg_name = $row["dg_name"];
			$d_duration = $row["d_duration"];
			//convert from 00:00:00 to hour decimal
			$timeArry = explode(':', $d_duration);
			$hour = $timeArry[0];
			$minutes = $timeArry[1];
			$max = $hour + $minutes/60;
		}
			$result->close();
	} else {
		$message = "Error C3P0";
		$loadError = true;
	}
}

//Pull uPrint material Price
if ($result = $mysqli->query("
	SELECT device_materials.m_id, price
	FROM materials
	LEFT JOIN device_materials
	ON materials.m_id = device_materials.m_id
	WHERE dg_id = 7
")){
	while( $row = $result->fetch_assoc() ) {
		$mats[$row["m_id"]] = $row["price"];
	}
		$result->close();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$status_id = 10;//set status id to "Powered On"
	// Check to see if UTA ID is a 10-digit number
	if (empty($_POST["uta_id"])){
		$utaErr = "UTA ID required";
		$error = true;
	} else {
		$uta_id = $_POST["uta_id"];
		if (preg_match("/^\d{10}$/",$uta_id) == 0) {
			$utaErr = "bad UTA ID";
			$error = true;
		}
	}
	// Check if time has been selected
	if ( $max > 0 ) { 
		$time = $max.":00:00";
	} elseif (!isset($_POST["hours"]) && !isset($_POST["minutes"])){
		$timeErr = "Specify Time".$_POST["hours"];
		$error = true;
	} elseif ( preg_match("/^\d{1,3}$/",$_POST["hours"]) == 0 && preg_match("/^\d{1,2}$/",$_POST["minutes"]) == 0) {
		$timeErr = "Invalid Time - ".$_POST["hours"].":".$_POST["minutes"];
		$error = true;
	} else {
		$hh = $_POST["hours"];
		$mm = $_POST["minutes"];
		$time = $_POST["hours"].":".$_POST["minutes"].":00";
	}
	
	// Check Purpose Visit
	if (empty($_POST["purp_id"])){
		$purpErr = "Select Purpose";
		$error = true;
	} elseif (preg_match("/^\d{1}$/",$_POST["purp_id"]) == 0) {
		$purp_id = $_POST["purp_id"];
		$purpErr = "Invalid Purpose - $purp_id";
		$error = true;
	} else {
		$purp_id = $_POST["purp_id"];
	}
	
	//uPrint Volume Check
	if (!$error){
		if($dg_name == 'uprint'){
			if (empty( $_POST["volume1"]) || empty( $_POST["volume1"])) {
				$weightErr = "Enter Volume";
				$error = true;
			} else {
				$volume1 = $_POST["volume1"];
				$volume2 = $_POST["volume2"];
				if ( !(preg_match("/^\d{0,4}\.{0,1}\d{0,4}$/", $volume1)) ) {
					$weightErr = "Invalid volume";
					$error = true;
				}
				if ( !(preg_match("/^\d{0,4}\.{0,1}\d{0,4}$/", $volume2)) ) {
					$weightErr = "Invalid volume";
					$error = true;
				} else {
					$weight1 = $volume1*$sv['uprint_conv'];
					$weight2 = $volume2*$sv['uprint_conv'];
					$rate1 = $mats["27"];
					$rate2 = $mats["32"];
					$total = round($weight1 * $rate1, 2) + round($weight2 * $rate2, 2);
				}
			}
		} else {
			// Check Material
			if (!isset($_POST["m_id"])){
				$mErr = "Select Material";
				$error = true;
			} elseif (preg_match("/^\d{1,4}$/", $_POST["m_id"]) && !$_POST["m_id"] == "none"){
				$mErr = "Invalid Material - ".$_POST["m_id"];
				$error = true;
			} else {
				$m_id = $_POST["m_id"];
			}
		}
	}
	

//if no form errors proceed	
	if (!$error){
		$_SESSION["time"] = (intval(time()) + $sv["limit"]);
		//uPrint go to pay screen
		if($dg_name == 'uprint'){
			$status_id = 10; //Set to Powered On
			if ($result = $mysqli->query("
			  INSERT INTO transactions 
				(`uta_id`,`device_id`,`t_start`,`status_id`,`purp_id`,`est_time`,`total`) 
			  VALUES
				('$uta_id','$device_id',CURRENT_TIMESTAMP,$status_id,'$purp_id','$time','$total');
			")){				
				$_SESSION["trans_id"] = $trans_id = mysqli_insert_id($mysqli);
				$weight1 = -$weight1;
				$weight2 = -$weight2;
				if ($result = $mysqli->query("
					INSERT INTO mats_used 
					  (`trans_id`, `m_id`, `status_id`, `unit_used`) 
					VALUES
					  ($trans_id, '27', $status_id, $weight1), ($trans_id, '32', $status_id, $weight2);
				")){
					$_SESSION["type"] = "pay";
					$_SESSION["dg_name"] = $dg_name;
					$_SESSION["rate1"] = $rate1;
					$_SESSION["rate2"] = $rate2;
					$_SESSION["status_id"] = $status_id;
					$_SESSION["total"] = $total;
					$_SESSION["uta_id"] = $uta_id;
					$_SESSION["weight1"] = abs($weight1);
					$_SESSION["weight2"] = abs($weight2);
					header("Location:pay.php");
				} else {
					$message = $mysqli->error;
				}
			} else {
				$message = $mysqli->error;
			}
		} else {
			if ($result = $mysqli->query("
			  INSERT INTO transactions 
				(`uta_id`,`device_id`,`t_start`,`purp_id`,`est_time`, `status_id`) 
			  VALUES
				('$uta_id','$device_id',CURRENT_TIMESTAMP,'$purp_id','$time', $status_id);
			")){
				$_SESSION["trans_id"] = $trans_id = mysqli_insert_id($mysqli);
				if ($m_id != "none") {
					if ($result = $mysqli->query("
						INSERT INTO mats_used 
						  (`trans_id`, `m_id`, `status_id`) 
						VALUES
						  ($trans_id, $m_id, $status_id);
					")){
						header("Location:report.php");
					} else {
						$message = $mysqli->error;
					}
				} else {
					header("Location:report.php");
				}
			} else {
				$message = $mysqli->error;
			}
		}
	}
} ?>
<html>
<head>
<link rel="shortcut icon" href="images/FabLab_Favicon.png?v=2" type="image/png">
	<title>FabLab E-Tickets</title>
	<link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<body>
<?php include 'header.php';?>
    <table border="0" cellpadding="10" cellspacing="1" width="500" align="center">
        <tr class="tableheader">
            <td align="center" colspan="2"><h1>Create New Ticket</h1>
			<div class="message"><?php if($message!="") { echo $message; } ?></div></td>
        </tr>
		<?php if (!$loadError) { ?>
        <form id="cform" name="cform" method="post" action="" onsubmit="return validateForm()">
        <tr class="tablerow">
            <td align="Center">Device</td>
            <td><?php echo $device_desc?><div class="message"><?php echo $deviceErr;?></div></td>
        </tr>
		<tr class="tablerow">
        	<td align="center">MavID Number</td>
            <td><input type="text" name="uta_id" placeholder="1000000000" value="<?php echo $uta_id;?>" autocomplete='off'
			 maxlength="10" size="10" autofocus tabindex="1"><div class="message"><?php echo $utaErr;?></div></td>
        </tr>
		<?php if (!strcmp($dg_name,"uprint")){
			//Material Input for uPrint?>
			<tr class="tableheader">
				<td align="center" colspan=2>Payment Required First<div id="uprint" style="float:right">$ 0.00 </div></td>
			</tr>
			<tr class="tablerow">
				<td align="center">Model Material</td>
				<td><input type="number" name="volume1" id="volume1" autocomplete="off" value="<?php echo $volume1;?>" min="0" max="1000" step=".01" tabindex="2" onchange="uPrint()" onkeyup="uPrint()"> in^3<div class="message"><?php echo $weightErr;?></div></td>
			</tr>
			<tr class="tablerow">
				<td align="center">Support Material</td>
				<td><input type="number" name="volume2" id="volume2" autocomplete="off" value="<?php echo $volume2;?>" min="0" max="1000" step=".01" tabindex="3" onchange="uPrint()" onkeyup="uPrint()"> in^3</td>
			</tr>
			
		<?php } else { ?>
        <tr class="tablerow">
			<?php if($result = $mysqli->query("
				SELECT materials.m_id, m_name 
				FROM devices
				JOIN device_materials
				ON devices.dg_id = device_materials.dg_id
				JOIN materials
				ON materials.m_id = device_materials.m_id
				WHERE device_id = $device_id
				ORDER BY m_name ASC
			")){
				if ($result->num_rows > 0){ ?>
					<td align="Center">Material</td>
					<td><select name="m_id" id="m_id" tabindex="3">
						<option disabled hidden selected value="">Select</option>
					<?php while ($row = $result->fetch_assoc()) {
						echo("<option value='".$row["m_id"]."'>".$row["m_name"]."</option>");
					}
					$result->close();
				} else { ?>
					<td align="Center">Material</td>
					<td><select name="m_id" id="m_id" tabindex="3">
						<option selected value="none">None</option>
			<?php	}
			} else {
				$message = "Error C3P0";
				$error = true;
			} ?>
			</select><div class="message"><?php echo $mErr;?></div></td>
		</tr>
		<?php } ?>
        <tr class="tablerow">
			<?php if ($max > 0){ ?>
			<td align="center">Max Time</td>
				<td>
					<input type="text" size="1" name="hours" disabled value="<?php echo $max?>"></input> Hour
				</td>
			<?php } else {?>
				<td align="center">Estimated Time</td>
				<td>
					<input type="number" name="hours" id="hours" tabindex="6" min="0" max="100" 
							step="1" placeholder="hh" value="<?php echo $hh?>"></input>Hours
					<select name="minutes" id="minutes" tabindex="7">
             		 <option value="00">00</option>
             		 <option value="05">05</option>
             		 <option value="10">10</option>
             		 <option value="15">15</option>
             		 <option value="20">20</option>
             		 <option value="25">25</option>
             		 <option value="30">30</option>
             		 <option value="35">35</option>
             		 <option value="40">40</option>
             		 <option value="45">45</option>
             		 <option value="50">50</option>
             		 <option value="55">55</option>
            </select>minutes<div class="message" id="timeErr"><?php echo $timeErr;?></div>
				</td>
			<?php } ?>
		</tr>
        <tr class="tablerow"><?php 
			if($result = $mysqli->query("
				SELECT purp_id, p_title 
				FROM purpose
				ORDER BY purp_id ASC
			")){
				if ($result->num_rows >= 0){ ?>
					<td align="Center">Purpose of Visit</td>
					<td><select name="purp_id" tabindex="8">
						<option disabled hidden selected value="">Select</option>
					<?php while ($row = $result->fetch_assoc()) {
						echo("<option value='".$row["purp_id"]."'>".$row["p_title"]."</option>");
					}
					$result->close();
				} else {
					$purpErr = "Error CUL8TR";
				}
			} else {
				$message = "Error CUL8TR";
				$error = true;
			} ?>
        	  </select><div class="message"><?php echo $purpErr;?></div></td>
		</tr>
        <tr class="tableheader">
            <td align="center"><input type="button" onClick="resetForm()" value="Reset form"></td>
        	<td align="right"><input type="submit" name="submit" value="Submit" tabindex="9" id="submitBtn"></td>
		</tr>
        </form>
		<?php } ?>
    </table>
</div>
</form>
<script type="text/javascript">
setTimeout(function(){window.location.reload(1)}, 301000);

function resetForm() {
		document.getElementById("form").reset();
	}
	
function validateForm() {
    var x = document.forms["cform"]["uta_id"].value;
	var reg = /^\d{10}$/;
	//Mav ID Check
    if (x == null || x == "" || !reg.test(x)) {
        if (!reg.test(x)) {
			alert("Invalid UTA ID");
		} else {
			alert("Please enter UTA ID");
		}
		document.forms["cform"]["uta_id"].focus();
        return false;
    }
	//Material Check Uprint
	<?php if (!strcmp($dg_name,"uprint")) { ?>
		var mm = document.forms["cform"]["volume1"].value;
		if (mm == null || mm == "") {
			alert("Please enter Material Volume");
			document.forms["cform"]["volume1"].focus();
			return false;
		}
		var sm = document.forms["cform"]["volume2"].value;
		if (sm == null || sm == "") {
			alert("Please enter Support Volume");
			document.forms["cform"]["volume2"].focus();
			return false;
		}
	<?php } else {?>
		//Material Check
		var y = document.forms["cform"]["m_id"].value;
		if (y == null || y == "") {
			alert("Please select a material");
			document.forms["cform"]["m_id"].focus();
			return false;
		}
	<?php } ?>
	//Max Time Check
	<?php if ($max > 0) { ?>
		var h = parseInt(document.forms["cform"]["hours"].value) || 0;
		var m = parseInt(document.forms["cform"]["minutes"].value) || 0;
		var max = <?php echo $max;?>;
		h = h + m/60;
		if (h > max){
			alert("Over Time Limit - " + max);
			document.forms["cform"]["hours"].value = max;
			document.forms["cform"]["minutes"].value = "";
			return false;
		}
	<?php } ?>
	//Purpose Check
    var p = document.forms["cform"]["purp_id"].value;
    if (p == null || p == "") {
        alert("Please select a Purpose");
		document.forms["cform"]["purp_id"].focus();
        return false;
    }
}

function uPrint () {
	var conv_rate = <?php echo $sv['uprint_conv'];?>;
	var rate1 = <?php echo $mats['27'];?>;
	var rate2 = <?php echo $mats['32'];?>;
	var volume1 = document.getElementById("volume1").value;
	var volume2 = document.getElementById("volume2").value;
	var total = ( (volume1 * conv_rate * rate1)+(volume2 * conv_rate * rate2) ).toFixed(2);
	document.getElementById("uprint").innerHTML = "$ " + total;
}
</script>
</body>
</html>