<div class="header">
	<nav>
		<ul>
			<li><a href="home.php">Tickets</a></li>
			<li><a href="tools.php">Tools</a></li>
			<li><a href="pickup.php">Pick-up 3D Print</a></li>
			<li><a href="look.php">Look Up Ticket</a></li>
			<li><a href="logout.php" title="Logout">Logout</a></li>
		</ul>
	</nav>
</div>