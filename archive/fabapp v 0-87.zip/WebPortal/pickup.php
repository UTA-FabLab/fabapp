<?php 
require_once("connections/db_connect8.php");
session_start();
date_default_timezone_set('America/Chicago');
$message = $utaErr = $uta_id = $unitError = "";

if(!isset($_SESSION["user_name"]) || $_SESSION["time"] < time()) {
	header("Location:logout.php");	
}
//Find by Student ID
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$_SESSION["time"] = (intval(time()) + $_SESSION["limit"]);
	if( !isset($_SESSION["type"]) ){
		if (empty($_POST["uta_id"])){
			$utaErr = "UTA ID required";
		} else{
			$uta_id = $_POST["uta_id"];
			ClaimObj($uta_id);
		}
	} elseif ( $_SESSION["type"] == "pickup"){
		if( empty($_POST["unit_used"]) ){
			$unitError = "Please Weight Object";
		} else {
			if( empty($_POST["status_id"]) ){
				$unitError = "Please Weight Object";
			} else {
				FinishPickUp($_SESSION["trans_id"], $_SESSION["uta_id"], $_POST["unit_used"], $_SESSION["price"], $_POST["status_id"]);
			}
		}
	}
}
function ClaimObj($uta_id){
	global $mysqli;
	global $utaErr;
	global $message;
	
	// Check to see if UTA ID is a 10-digit number
    if (preg_match("/^\d{10}$/",$uta_id) == 0) {
        $utaErr = "bad UTA ID";
        return;
    }
	//find objects that belong to uta_id
	if ($result = $mysqli->query("
		Select transactions.trans_id, address, mats_used.unit_used, mats_used.m_id, device_id
		FROM objbox JOIN transactions
		ON transactions.trans_id=objbox.trans_id
		LEFT JOIN mats_used
		ON transactions.trans_id = mats_used.trans_id
		WHERE uta_id = '$uta_id' AND pickupid IS NULL
		ORDER BY t_start DESC
	")){
		//if result is NULL Look at Auth Recipients Table
		$numRows = $result->num_rows;
		if(($numRows) == 0){
			$result->close();//close old result
			if ($result = $mysqli->query("
				SELECT objbox.trans_id, address, unit_used, m_id, device_id
				FROM objbox JOIN authrecipients
				ON objbox.trans_id = authrecipients.trans_id
				JOIN transactions
				ON authrecipients.trans_id = transactions.trans_id
				WHERE authrecipients.uta_id = '$uta_id' AND pickupid is NULL
			")){
				if(($result->num_rows) == 0){
					$message = 'No unclaimed objects found. <a href="look.php?uta_id='.$uta_id.'">Look up Last Ticket?</a>';
					return;
				}
			} else {
				echo("Error - 4734");
				return;
			}
		}
		$row = $result->fetch_assoc();
		$unit_used = floatval($row["unit_used"]);
		$m_id = $row["m_id"];
		//get price of material
		if ($m_id == 0 )
			$m_id = 1;
		if ($result_m = $mysqli->query("SELECT price FROM materials WHERE m_id = '$m_id'")){
			$row_m = $result_m->fetch_assoc();
			$result_m->close();
			$price = floatval($row_m["price"]);
			$total = -round($unit_used * $price, 2);
		} else {
			//$message = "Error - Fetching Price $m_id";
			$message = $mysqli->error;
			return;
		}
		//set item to pickup
		$trans_id = $row["trans_id"];
		if ( ($_SESSION["device_id"]=="0043") ) {
			//update ObjBox Table
			if ($mysqli->query("
				UPDATE `objbox`
				SET `pickupid` = '$uta_id', `o_end` = CURRENT_TIMESTAMP
				WHERE `trans_id` = $trans_id;
			")){ } else {
				$message = "Update Object Manager Error";
				return;
			}
		}
		$_SESSION["type"] = "pickup";
		$_SESSION["device_id"] = $row["device_id"];
		$_SESSION["price"] = $price;
		$_SESSION["uta_id"] = $uta_id;
		$_SESSION["unit_used"] = -$unit_used;
		$_SESSION["trans_id"] = $trans_id;
		$_SESSION["address"]= $row["address"];
		$_SESSION["total"]= $total;
		header("Location:pickup.php");
	} else {
        $message = "No Objects Found";
	}
}

function FinishPickUp($trans_id, $uta_id, $unit_used, $price, $status_id){
	global $mysqli;
	global $message;
	
	//If it has failed there is No Charge
	if ($status_id == 12) {
		$total = 0;
	} else {
		$total = $unit_used * floatval($_SESSION["price"]);
		$unit_used = -abs($unit_used);
	}
	
	//Update transaction end & materials used
	if( $mysqli->query("
		UPDATE `transactions`, `mats_used`
		SET total = '$total', t_end = CURRENT_TIMESTAMP,
			duration = SEC_TO_TIME (TIMESTAMPDIFF (SECOND, t_start, CURRENT_TIMESTAMP)),
			mats_used.unit_used = $unit_used, mats_used.status_id = $status_id, transactions.status_id = $status_id
		WHERE transactions.trans_id = $trans_id and transactions.trans_id = mats_used.trans_id;
	")){
		//update ObjBox Table
		if ($mysqli->query("
			UPDATE `objbox`
			SET `pickupid` = '$uta_id', `o_end` = CURRENT_TIMESTAMP
			WHERE `trans_id` = $trans_id;
		")){ } else {
			$message = "Update Object Manager Error";
			return;
		}
	} else {
		$message = $mysqli->error;
		return;
	}
	unset($_SESSION["address"]);
	$_SESSION["type"] = "pay";
	$_SESSION["unit_used"] = abs($unit_used);
	$_SESSION["trans_id"] = $trans_id;
	$_SESSION["status_id"] = $status_id;
	$_SESSION["total"]= $total;
	header("Location:pay.php");
}
?>
<html>
<head>
<link rel="shortcut icon" href="images/fa-icon.png" type="image/png">
	<title>FabLab PickUp 3D Print</title>
	<link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<body>
<?php include 'header.php';
if( !isset($_SESSION["type"]) ){
	unset($_SESSION["address"]);
	?>
	
		<table border="0" cellpadding="10" cellspacing="1" width="500" align="center">
			<form id="pform" name="pform" method="post" action="" autocomplete="off" onsubmit="submitBtn.disabled = true; return true;">
			<tr class="tableheader">
				<td align="center" colspan="2"><h1>Pick Up 3D Print</h1>
				<div class="header"><?php if($message!="") { echo $message; } ?></div>
				</td>
			</tr>
			<tr class="tablerow" id="transaction">
				<td align="right">Mav ID #</td>
				<td><input type="text" name="uta_id" placeholder="1000000000" <?php echo $uta_id;?>" autocomplete='off'
				 maxlength="10" size="10" autofocus><div class="message"><?php echo $utaErr;?></div></td>
			</tr>
			<tr class="tableheader">
			<td align="center" colspan="2"><input type="submit" name="submit" value="Submit" id="submitBtn"></td>
			</tr>
			</form>
		</table>
<?php } elseif ( $_SESSION["type"] == "pickup"){ ?>
		<table border="0" cellpadding="10" cellspacing="1" width="500" align="center">
			<form id="pform" name="pform" method="post" action="" autocomplete="off" onsubmit="submitBtn.disabled = true; return true;">
				<tr class="tableheader">
					<td align="center" colspan="2"><h1>Pick Up 3D Print</h1>
					<div class="header"><?php if($message!="") { echo $message; } ?></div>
					</td>
				</tr>
				<tr class="tablerow">
					<td align="right">Ticket #</td>
					<td align="center"><?php echo $_SESSION["trans_id"] ?></td>
				</tr>
				<tr class="tablerow">
					<td align="right">Weight</td>
					<td align="center">$<?php echo $_SESSION["price"]; ?> at <input type="number" name="unit_used" id="unit_used" autocomplete="off" 
					value="<?php echo $_SESSION["unit_used"];?>" min="0" max="1000" step="1" style="text-align: right"
					onchange="calculate(<?php echo $_SESSION["price"];?>)" onkeyup="calculate(<?php echo $_SESSION["price"];?>)"> grams
					<div class="message"><?php echo $unitError;?></div></td>
				</tr>
				<tr	<tr class="tablerow">
					<td align="right">Cost</td>
					<td align="center"><div name="total" id="total">$ <?php echo $_SESSION["total"]; ?></div></td>
				</tr>
				<tr class="tablerow">
					<td align="right">Print Status</td>
					<td align="center">
						<select name="status_id" id="status_id">
							<option value="20" id="complete" selected>Pay</option>
							<option value="12" id="failed">Failed</option>
							<option value="21" id="fablab">FabLab Account</option>
							<option value="22" id="library">Library Account</option>
					</select></td>
				</tr>
				<tr class="tablerow">
					<td align="right">Placed on Shelf</td>
					<td align="center"><b><?php echo $_SESSION["address"];?></b></td>
				</tr>
				<tr class="tableheader">
					<td align="center" colspan="2"><input type="submit" name="submit" value="Confirm" id="submitBtn"></td>
				</tr>
			</form>	
<?php } ?>
<script type="text/javascript">
setTimeout(function(){window.location.reload(1)}, 301000);


function calculate (rate) {
	var status_id = document.getElementById("status_id").value;
	switch(status_id){
		case "20":
			var weight = document.pform.unit_used.value;
			var total = (weight * rate).toFixed(2);
			var currency = "$ ";
			document.getElementById("total").innerHTML = currency.concat(total);
			break;
		case "12": 
		case "21":
		case "22":
			document.getElementById("total").innerHTML = "$ 0.00";
	}
}
</script>
</body>
</html>