<?php
date_default_timezone_set('America/Chicago');
require_once("connections/db_connect8.php");
require_once("site_variables.php");
session_start();
$message = $set = "";
unset($_SESSION["limit"]);
unset($_SESSION["user_name"]);
// Check where incoming request is coming from and
// limit requests to UTA Library staff subnets:
// 129.107.37.* and 129.107.76.*
$ip = getenv('REMOTE_ADDR');

if(count($_POST)>0) {
	if (strcmp ($_POST["password"], "Beta2016") == 0){
		//if (! ((preg_match("/^129\.107\.37\..*/",$ip)) || (preg_match("/^129\.107\.73\..*/",$ip)))) {
		//	header("Location:index.php");
		//} else {
			$_SESSION["user_name"] = "FabLabian";
			$_SESSION["limit"] = $sv["limit"];
			$_SESSION["time"] = (intval(time()) + $_SESSION["limit"]);
		//}
	} elseif (strcmp ($_POST["password"], "dev") == 0){
		$_SESSION["user_name"] = "SuperFablabian";
		$_SESSION["limit"] = $sv["limit_long"];
		$_SESSION["time"] = (intval(time()) + $_SESSION["limit"]);
	} else {
		$message = "Invalid Password!";
	}
}
if(isset($_SESSION["user_name"])) {
	header("Location:home.php");
}

?>
<html>
<head>
<link rel="shortcut icon" href="images/FabLab_Favicon.png?v=2" type="image/png">
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<body>
<div align="center">
	<img src="images/FabLab_Favicon.png" type="image/png">
</div>
	<form name="frmUser" method="post" action="" autocomplete="off" onsubmit="submitBtn.disabled = true; return true;">
	<div class="message"><?php if($message!="") { echo $message; } ?></div>
	<table border="0" cellpadding="10" cellspacing="1" width="500" align="center">
		<tr class="tableheader">
			<td align="center" colspan="2"><div class="message" >
				Staff Only
			</div></td>
		</tr>
		<tr class="tablerow">
			<td align="right">Password</td>
			<td><input type="password" name="password" autocomplete="off" autofocus></td>
		</tr>
		<tr class="tableheader">
		<td align="center" colspan="2"><input type="submit" name="submit" value="Submit" id="submitBtn"></td>
		</tr>
	</table>
	</form>
</body>
</html>