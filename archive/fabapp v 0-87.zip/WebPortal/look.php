<?php
require_once("connections/db_connect8.php");
session_start();
date_default_timezone_set('America/Chicago');
$message = $utaErr = $uta_id = "";
$display = false;
$result_array = array();

if( !isset($_SESSION["user_name"]) || ($_SESSION["time"] < time()) ) {
	header("Location:logout.php");
}
if (isset($_GET["trans_id"])){
	$trans_id = $_GET["trans_id"];
	if ( !(preg_match("/^\d*$/",$trans_id)) ) {
		$message = "Invalid Transaction Number";
	} else {
		TransLook($trans_id);
	}
}
if (isset($_GET["uta_id"])){
	$uta_id = $_GET["uta_id"];
	if ( !(preg_match("/^\d*$/",$uta_id)) ) {
		$message = "Invalid UTA Number";
	} else {
		UtaLook($uta_id);
	}
}
$_SESSION["time"] = (intval(time()) + $_SESSION["limit"]);
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	if(!empty($_POST["Ttype"])) {
		if ($_POST["Ttype"] == "uta_id"){
			// Check to see if UTA ID is a 10-digit number
			if (empty($_POST["uta_id"])){
				$utaErr = "UTA ID required";
			} else {
				$uta_id = $_POST["uta_id"];
				if (preg_match("/^\d{10}$/",$uta_id) == 0) {
					$utaErr = "bad UTA ID";
				} else {
					UtaLook($uta_id);
				}
			}
		} else {	
			// Check for valid transaction ID value
			if (empty($_POST["trans_id"])){
				$message = "Transaction Number Required";
			} else {
				$trans_id = $_POST["trans_id"];
				if ( !(preg_match("/^\d*$/",$trans_id)) ) {
					$message = "Invalid Transaction Number";
				} else {
					TransLook($trans_id);
				}
			}
		}
	} else {
		$message = "Please make a selection";
	}
}

function UtaLook($uta_id){
	global $mysqli;
	global $message;
	
	if($result = $mysqli->query("
		SELECT trans_id
		FROM transactions
		WHERE transactions.uta_id = '$uta_id'
		ORDER BY t_start DESC
		Limit 1
	")){
		if( $result->num_rows > 0){
			$row = $result->fetch_assoc();
			$trans_id = $row['trans_id'];
		} else {
			$message = "No Transactions Found for ID# $uta_id";
			return;
		}
	} else {
		$message = "Error - UTA LookUp";
	}
	TransLook($trans_id);
}
function TransLook($trans_id){
	global $mysqli;
	global $message;
	global $display;
	global $result_array;
	
	if ($result = $mysqli->query("
		SELECT uta_id, est_time, mats_used.unit_used, t_start, t_end, duration, total, device_desc, p_title, m_name, unit, o_start, o_end, address, pickupid, msg, p_title
		FROM transactions
		LEFT JOIN devices
		ON transactions.device_id = devices.device_id
		LEFT JOIN purpose
		ON transactions.purp_id = purpose.purp_id
		LEFT JOIN mats_used
		ON transactions.trans_id = mats_used.trans_id
		LEFT JOIN materials
		ON mats_used.m_id = materials.m_id
		LEFT JOIN status
		ON transactions.status_id = status.status_id
		LEFT JOIN objbox
		ON transactions.trans_id = objbox.trans_id
		WHERE transactions.trans_id = $trans_id
	")){
		if ($result->num_rows >= 1) {
			$display = true;
			$row = $result->fetch_assoc();
			if ( isset ($row["t_end"]) )
				$t_end = date( 'M d, Y g:i a',strtotime($row["t_end"]) );
			else 
				$t_end = '-';
			if ( isset($row["o_start"]) ){
				$o_start = date( 'M d, Y g:i a',strtotime($row["o_start"]) );
				if ( isset($row["o_end"]) )
					$o_end = date( 'M d, Y g:i a',strtotime($row["o_start"]) );
				else 
					$o_end = "-";
			} else {
				$o_start = $o_end = "-";
			}
			$result_array = array(
				array("Ticket #", $trans_id ),
				array("UTA ID#", $row["uta_id"] ),
				array("Device", $row["device_desc"] ),
				array("Estimated Time", date( 'g:i',strtotime($row["est_time"]) ) ),
				array("Start", date( 'M d, Y g:i a',strtotime($row["t_start"]) ) ),
				array("End", $t_end ),
				array("Duration", $row["duration"] ),
				array("Material", $row["m_name"] ),
				array($row["unit"]." used", abs($row["unit_used"]) ),
				array("Status", $row["msg"]),
				array("Total Cost", $row["total"] ),
				array("Purpose", $row["p_title"] ),
				array("Object Moved On",  $o_start),
				array("Placed on Shelf", $row["address"] ),
				array("Picked Up By", $row["pickupid"] ),
				array("Picked Up On", $o_end)
			);

			$result->close();
		} else {
			$message = "Transaction Not Found - $trans_id";
			return;
		}
	} else {
		$message = $mysqli->error;
		return;
	}
}
?>
<html>
<head>
<link rel="shortcut icon" href="images/fa-icon.png?v=2" type="image/png">
	<title>FabLab Look Up Ticket</title>
	<link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<?php include 'header.php';?>
<body>
	<table border="0" cellpadding="10" cellspacing="1" width="500" align="center">
	<?php if (!$display) { ?>
	<form id="radioform" name="radioform" method="post" action="" autocomplete="off" onsubmit="submitBtn.disabled = true; return true;">
		<tr class="tableheader">
			<td align="center" colspan="2"><h1>Look up Ticket by</h1>
				<input type="radio" name="Ttype" value="trans" id="trans" checked><label for="trans">Transaction</label>
				<input type="radio" name="Ttype" value="uta_id" id="uta"><label for="uta">UTA ID</label>
				<div class="header"><?php if($message!="") { echo $message; } ?></div>
			</td>
		</tr>
	
		<tr class="tablerow" id="transaction">
			<td align="right">Transaction Number</td>
			<td><input type="number" name="trans_id" autocomplete="off" min="0" class="trans" autofocus></td>
		</tr>
		<tr class="tablerow" id="device">
			<td align="right">UTA ID# (must be present)</td>
			<td><input type="text" name="uta_id" placeholder="1000000000" autocomplete='off'
			 maxlength="10" size="7" disabled><div class="message"><?php echo $utaErr;?></div></td>
		</tr>
		<tr class="tablerow">
			<td align="center" colspan="2"><input type="submit" name="submit" value="Submit" id="submitBtn"></td>
		</tr>
	</form>
	<?php } else {?>
		<tr class="tableheader">
			<td align="center" colspan="2"><h1>Result</h1></td>
		</tr>
		<?php foreach( $result_array as $line){ ?>
		<tr class="tablerow" id="transaction">
			<td align="right"><?php echo $line[0]; ?></td>
			<td align="center"> <?php
			if ($line[1]) 
				echo $line[1];
			else
				echo "-";
			?> </td></tr>
		<?php } ?>
	<?php } ?>
	</table>
<script type="text/javascript">
setTimeout(function(){window.location.reload(1)}, 301000);
<?php if (!$display) { ?>
	var form = document.forms['radioform'];
	form.Ttype[0].onfocus = function () {
		form.trans_id.disabled = false;
		form.uta_id.value = "";
		form.uta_id.disabled = true;
	}
	form.Ttype[1].onfocus = function () {
		form.trans_id.disabled = true;
		form.trans_id.value = "";
		form.uta_id.disabled = false;
	}
<?php } ?>
</script>
</body>
</html>