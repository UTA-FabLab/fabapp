<?php
date_default_timezone_set('America/Chicago');
require_once("connections/db_connect8.php");
require_once("site_variables.php");
$device_array = array();

?>
<html>
<head>
<link href="https://fonts.googleapis.com/css?family=Raleway:900" rel="stylesheet">
<link rel="shortcut icon" href="images/fa-icon.png?v=2" type="image/png">
	<title>FabApp - FabLab's Device Status</title>
	<link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<body>
<?php if($sv["serving"] == 0 ) {?>
	<div align="center">
		<img src="images/fabapp.png" type="image/png">
	</div>
<?php } else { ?>
	<table border="0" cellpadding="10" cellspacing="1" align="center">
		<tr>
			<td rowspan="2"><img src="images/fabapp.png" type="image/png"></td>
			<td align="center" bgcolor="2b2b2b"><p style="color:white">Now Serving</p></td>
		</tr>
		<tr>
			<td bgcolor="2b2b2b"><p style="font-family: 'Raleway', sans-serif; color:red; font-size:800%;
			margin-top:-30px; margin-bottom:-20px"><?php echo $sv['serving'];?></p></td>
		</tr>
	</table>
<?php } ?>
	
	<table border="0" cellpadding="10" cellspacing="1" width="800" align="center">
	<form>
		<tr class="tableheader">
			<td align="center" colspan="4"><h1>Device Status</h1>
			</td>
		</tr>
		<tr class="tablerow">
			<td align="right">Ticket #</td>
			<td>Device</td>
			<td>Start Time</td>
			<td>Est Remaining Time</td>
		</tr>
		<?php if ($result = $mysqli->query("
				SELECT trans_id, device_desc, t_start, est_time, devices.dg_id, dg_parent, devices.device_id, url
				FROM devices
				JOIN device_group
				ON devices.dg_id = device_group.dg_id
				LEFT JOIN (SELECT trans_id, t_start, t_end, est_time, device_id FROM transactions WHERE status_id < 12 ORDER BY trans_id DESC) as t 
				ON devices.device_id = t.device_id
				WHERE public_view = 'Y'
				GROUP BY `device_name`
				ORDER BY dg_id, `device_name`
			")){
				while ( $row = $result->fetch_assoc() ){ ?>
				<tr class="tablerow">
					<?php if($row["t_start"]) { ?>
						<td align="right"><?php echo $row["trans_id"]; ?></td>
						<?php if($row["url"]){ ?>
							<td><?php echo ("<a href=\"http://".$row["url"]."\">".$row["device_desc"]."</a>"); ?></td>
						<?php }else{ ?>
							<td><?php echo $row["device_desc"]; ?></td><?php } ?>
						<td> <?php echo( date( 'M d, Y g:i a',strtotime($row["t_start"]) ) ); ?></td>
						<?php if( isset($row["est_time"]) ){
							echo("<td align=\"center\"><div id=\"est".$row["trans_id"]."\">".$row["est_time"]." </div></td>" ); 
						} else 
							echo("<td align=\"center\">-</td>");
 
						$str_time = preg_replace("/^([\d]{1,2})\:([\d]{2})$/", "00:$1:$2", $row["est_time"]);
						sscanf($str_time, "%d:%d:%d", $hours, $minutes, $seconds);
						$time_seconds = $hours * 3600 + $minutes * 60 + $seconds;
						$time_seconds = $time_seconds - (time() - strtotime($row["t_start"]) ) + 600;
						array_push($device_array, array($row["trans_id"], $time_seconds, $row["dg_parent"]) );
					} else { ?>
						<td align="right"></td>
						<?php if($row["url"]){ ?>
							<td><?php echo ("<a href=\"http://".$row["url"]."\">".$row["device_desc"]."</a>"); ?></td>
						<?php }else{ ?>
							<td><?php echo $row["device_desc"]; ?></td><?php } ?>
						<td align="center"> - </td>
						<td align="center"> - </td>
					<?php } ?>
				</tr>
		<?php
				}

			} 
		?>
	</form>
	<tr class="tableheader">
		<td align="center" colspan="3"><a href="tools.php">Quote</a></td>
		<td align="center" ><a href="login.php">Staff Login</a></td>
	</tr>
	</table>
</body>
<script type="text/javascript">
setTimeout(function(){window.location.reload(1)}, 100000);

function startTimer(duration, display, dg_parent) {
    var timer = duration, hours, minutes, seconds;
    setInterval(function () {
		if (timer > 0) {
			hours = parseInt(timer / 3600, 10);
			minutes = parseInt( (timer-(hours*3600))/60, 10);
			seconds = parseInt(timer % 60, 10);
			hours = hours < 10 ? hours : hours;
			minutes = minutes < 10 ? "0" + minutes : minutes;
			seconds = seconds < 10 ? "0" + seconds : seconds;
			
			display.textContent = hours + ":" + minutes + ":" + seconds;
			--timer;
		} else {
			hours = Math.abs(parseInt(timer / 3600, 10));
			minutes = Math.abs(parseInt( (timer+(hours*3600))/60, 10));
			seconds = Math.abs(parseInt(timer % 60, 10));
			hours = hours < 10 ? hours : hours;
			minutes = minutes < 10 ? "0" + minutes : minutes;
			seconds = seconds < 10 ? "0" + seconds : seconds;
			
			display.textContent = "- "+ hours + ":" + minutes + ":" + seconds;
			display.className="message";
			--timer;
		}
		
		if (timer == 0 && dg_parent == 1){
			window.alert("A Printer's time has expired");
			window.location.reload(1);
		}
		
    }, 1000);
}

window.onload = function () {
	<?php foreach ($device_array as $da) { ?>
		var time = <?php echo $da[1];?>;
		var display = document.getElementById('est<?php echo $da[0];?>');
		var dg_parent = <?php if ($da[2]) echo $da[2]; else echo "0";?>;
		startTimer(time, display, dg_parent);
		
	<?php } ?>
};
</script>
</html>