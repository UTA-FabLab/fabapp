<?php

/*
 *  Flapp.php : FabLab Application 
 *
 *
 *  Jonathan Le, Super FabLabian
 *	FabLab @ University of Texas at Arlington
 *
 *  version: 0.1 beta (2016)
 *
*/

// Requests/replies via JSON data exchange
// =======================================
// 1) LDAP Authorization
// 2) Insert Object into Box
// 3) Request List of Unclaimed Objects
// 4) Claim Object
// 5) Add Authorized Recipients 
// 6) 

date_default_timezone_set('America/Chicago');
require_once __DIR__ ."..\db_connect8.php";
include 'gatekeeper.php'; 
$json_out = array();

// Check where incoming request is coming from and
// limit requests to UTA Library staff subnets:
// 129.107.67.* and 129.107.76.*
// $ip = getenv('REMOTE_ADDR');
// if (! ((preg_match("/^129\.107\.67\..*/",$ip))
//    || (preg_match("/^129\.107\.76\..*/",$ip)))) {
//     $json_out["ERROR"] =  "Requests not accepted from $ip";
//     ErrorExit(3);
// }

/*
// Input posted with "Content-Type: application/json" header
$input_data = json_decode(file_get_contents('php://input'), true);
if (! ($input_data)) {
	$json_out["ERROR"] = "Unable to decode JSON message - check syntax";
	ErrorExit(1);
}
// Extract message type from incoming JSON
$type = $input_data["type"];
*/
$input_data["jwt"] = "protcol:header:payload";
$input_data["type"] = "claimobj";
$input_data["uta_id"] = "1000000009";
//$input_data["uta_id"] = "1000129288";
//$input_data["type"] = "insertobj";
//$input_data["device_id"] = "0010";

if (isset($input_data["jwt"])) {
	$json_out["JWT"] = "Perform Check and Log";
	switch (strtolower($input_data["type"])) {
		case "insertobj":
			if (isset( $input_data["trans_id"])) {
				$trans_id = $input_data["trans_id"];
			} else {
				$trans_id = 0;
			}
			if (isset( $input_data["device_id"])) {
				$device_id = $input_data["device_id"];
			} else {
				$device_id = NULL;
			}
			InsertObj($trans_id, $device_id);
			break;
		case "listobj":
			ListObj();
			break;
		case "claimobj":
			ClaimObj($input_data["uta_id"]);
			break;
		case "pay":
			$trans_id = $input_data["trans_id"];
			$uta_id = $input_data["uta_id"];
			Pay($trans_id, $uta_id);
			break;
		case "regrecip":
			$trans_id = $input_data["trans_id"];
			$uta_id = $input_data["uta_id"];
			RegRecip($trans_id, $uta_id);
			break;
		default:
			$json_out["ERROR"] = "Request not recognized";
			ErrorExit(1);
	}
} else {
	$json_out["ERROR"] = "Unable to Authenticate User";
	ErrorExit(1);
}

header("Content-Type: application/json");
echo json_encode($json_out);
exit(0);

/**********         Functions         **********/

/////////////////////////////////////////////////////
//        Transfers newly printed object 
//            to ObjectBox Storage
function InsertObj($trans_id, $device_id){
    global $json_out;
	global $mysqli;
	$i = 0;
	$letter = array("A","B","C");

	if( isset($device_id)){			
		// Check to see if device ID is a valid 4-digit number
		if (preg_match("/^\d{4}$/",$device_id) == 0) {
			$json_out["ERROR"] = "Invalid or missing device id value - $device_id";
			ErrorExit(1);
		}
		//sql search for last transaction for device_id
		if ($result = $mysqli->query("
			SELECT transactions.trans_id, t_start
			FROM transactions
			LEFT JOIN objbox on transactions.trans_id = objbox.trans_id
			WHERE objbox.trans_id IS NULL AND transactions.device_id = '$device_id'
			UNION
			SELECT transactions.trans_id, t_start
			FROM transactions
			LEFT JOIN objbox on transactions.trans_id = objbox.trans_id
			WHERE transactions.trans_id IS NULL AND transactions.device_id = '$device_id'
			ORDER BY t_start DESC
		")){
			if ( $result->num_rows > 1){
				$json_out["trans_array"] = array();
				while($row = $result->fetch_assoc()){
					array_push($json_out["trans_array"], $row);
				}
				$result->close();
				return;
			} else {
				$row = $result->fetch_assoc();
				$json_out["trans_id"] = $row["trans_id"];
				$trans_id = $row["trans_id"];
			}
		}
	}
	// Check for valid transaction ID value
    if ( !(preg_match("/^\d*$/",$trans_id)) ) {
        $json_out["ERROR"] = "Invalid trans_id";
        ErrorExit(1);
    } elseif ($trans_id == 0) {
        $json_out["ERROR"] = "No transactions found.";
        ErrorExit(1);
	}
	//Check if transaction already has a home
	if ($result = $mysqli->query("
		SELECT address
		FROM objbox
		Where trans_id = '$trans_id'
	")){
		//exit if so
		if ($row = $result->fetch_assoc()){
			$address = $row["address"];
			$json_out["ERROR"] = "Transaction already has an object box, $address";
			return;
		}
	}
	//Generate Address
	if ($result = $mysqli->query("SELECT address FROM objbox WHERE o_end IS NULL ORDER BY address ")) {
		$occupied = array();
		while ($row = $result->fetch_assoc()){
			array_push($occupied, $row["address"]);
		}
		$result->close();
		$address = rand(1,50).$letter[rand(0,2)];
		$test = TRUE;
		while( $test == TRUE){//searches for a match
			if (strcmp($address,$occupied[$i]) == 0){
				//echo($address." = ".$occupied[$i]."\n");
				$address = rand(1,50).$letter[rand(0,2)];
				$i = 0;
			}
			//echo($address." != ".$occupied[$i]."\n");
			$i++;
			if($i == count($occupied))
				$test = False;
		}
		//echo("suggested address = ".$address."\n");
		$json_out["address"] = $address;
	} else {
        $json_out["ERROR"] = $mysqli->error;
        ErrorExit(2);
	}
	
	//Log moving item into ObjManager
	if ($mysqli->query("
		INSERT INTO objbox (`trans_id`,`o_start`,`address`) 
		VALUES ('$trans_id',CURRENT_TIMESTAMP,'$address')"
	)){
		$json_out["o_id"] = $mysqli->insert_id;
    }else {
        $json_out["ERROR"] = $mysqli->error;
        ErrorExit(2);
    }
}

/////////////////////////////////////////////////////
//        Query creates a list of unclaimed 
//          objects that are in inventory
function ListObj(){
    global $json_out;
	global $mysqli;
	
	if ($result = $mysqli->query(" SELECT o_id, o_start, address, trans_id FROM objbox WHERE o_end IS NULL;")) {
		$json_out["objects"] = array();
		while($row = $result->fetch_assoc()){
			array_push($json_out["objects"], $row);
		}
		$result->close();
	} else {
        $json_out["ERROR"] = $mysqli->error;
        ErrorExit(2);
	}
}

////////////////////////////////////////////////////////////////
//				Send MavID to claim an object
//
function ClaimObj($uta_id){
    global $json_out;
	global $mysqli;
	
	// Check to see if UTA ID is a 10-digit number
    if (preg_match("/^\d{10}$/",$uta_id) == 0) {
        $json_out["ERROR"] = "bad UTA ID";
        ErrorExit(1);
    }
	//find objects that belong to uta_id
	if ($result = $mysqli->query("
		Select transactions.trans_id, address, filament_amt, m_id
		FROM objbox JOIN transactions
		ON transactions.trans_id=objbox.trans_id
		WHERE uta_id = '$uta_id' AND pickupid IS NULL
	")){
		//if result is NULL Look at Auth Recipients Table
		if(!$result->fetch_assoc()){
			$result->close();//close old result
			if ($result = $mysqli->query("
				SELECT objbox.trans_id, address, filament_amt, m_id
				FROM objbox JOIN authrecipients
				ON objbox.trans_id = authrecipients.trans_id
				JOIN transactions
				ON authrecipients.trans_id = transactions.trans_id
				WHERE authrecipients.uta_id = '$uta_id'
			")){
				//echo("Found related transaction.");
			}
		}
		
		$json_out["objects"] = array();
		while($row = $result->fetch_assoc()){
			$filament_amt = floatval($row["filament_amt"]);
			$trans_id = $row["trans_id"];
			$m_id = $row["m_id"];
			//get price of material
			if (!$m_id)
				$m_id = 1;
			if ($result_m = $mysqli->query("SELECT price FROM material WHERE '$m_id'")){
				$row_m = $result_m->fetch_assoc();
				$result_m->close();
				$price = floatval($row_m["price"]);
				$row["total"] = round($filament_amt * $price, 2);
			}
			array_push($json_out["objects"], $row);
		}
		$result->close();
	} else {
        $json_out["ERROR"] = $mysqli->error;
        ErrorExit(2);
	}
}

////////////////////////////////////////////////////////////////
//         Register Recipients - Register a UTA ID to transaction
function RegRecip(){}

////////////////////////////////////////////////////////////////
//         Pay for object - Update transaction & objBox tables
function Pay(){}


////////////////////////////////////////////////////////////////
//         ErrorExit - Sends error message and quits 
function ErrorExit ($exit_status) {
	global $mysqli;
    global $json_out;
    header("Content-Type: application/json");
	$mysqli->close();
    echo json_encode($json_out);
    exit($exit_status);
}
?>