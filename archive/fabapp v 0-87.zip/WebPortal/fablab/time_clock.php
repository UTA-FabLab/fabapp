<?php
/* these are the server variables , change these to server details */

// sulicats server

/*
$servername = "localhost";
$username = "sulicat_suli";
$password = "myfatcat";
$dbname = "sulicat_fabapp_final";
*/


// fabapp server
require_once( __DIR__."/../connections/db_connect8.php");

$rfid = htmlspecialchars( $_POST["rfid"] );
$time_in = htmlspecialchars( $_POST["time"] );
$utaid = "";
$checking_in = True;
$exists = False;
$row_id = 0;
$rfid_no_comma = str_replace( ',', '', $rfid );
//$mysqli = new mysqli($servername, $username, $password, $dbname);
//$row_id = 0;


/* this is the part that checks whether the rfid is on the rfid
    accepted list, then gets the equivilant uta id */

$sql = "SELECT uta_id FROM rfid WHERE rfid_no=$rfid";
$result = $mysqli->query($sql);
$checking_in = True;

// get the uta_id
$row = $result->fetch_assoc();
$utaid = $row['uta_id'];
if($utaid == NULL){
	$exists = False;
}else{
	$exists = True;
}






if($exists == False){
	echo "bad";
} else {	
	$sql = "SELECT id FROM time_clock WHERE uta_id = $utaid AND end_time is NULL";
	$result = $mysqli->query($sql);
	$row = $result->fetch_assoc();
	$id = $row['id'];
	
	if($row == NULL){
		$sql = "INSERT INTO time_clock (uta_id, start_time) VALUES ($utaid, CURRENT_TIMESTAMP)";
		$result = $mysqli->query($sql);
		echo "checking in";
		
	}else{		
		$sql = "UPDATE time_clock SET duration = TIMESTAMPDIFF(SECOND, start_time, CURRENT_TIMESTAMP) WHERE id=$id";
		$result = $mysqli->query($sql);
		$sql = "UPDATE time_clock SET end_time = CURRENT_TIMESTAMP WHERE id=$id";
		$result = $mysqli->query($sql);
		echo "checking out";
		
	}
	
}
?>

