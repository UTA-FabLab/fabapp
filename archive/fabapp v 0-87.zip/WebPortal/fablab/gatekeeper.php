<?php


///////////////////////////////////////////////////////////////
//
//   IsAuthorized
//   Checks to see if UTA ID is authorized to use a FabLab device

function IsAuthorized ($uta_id, $device_id) {
	global $json_out;
	global $mysqli;
	
    //$json_out["utaid"] =  $uta_id;

    // Check to see if UTA ID is a 10-digit number
    if (preg_match("/^\d{10}$/",$uta_id) == 0) {
        $json_out["ERROR"] = "bad UTA ID";
        ErrorExit(1);
    }

    // Check to see if device ID is a valid 4-digit number
    if (preg_match("/^\d{4}$/",$device_id) == 0) {
        $json_out["ERROR"] = "Invalid or missing device id value - $device_id";
        ErrorExit(1);
    }
	
	
    // Check to see if device has training modules
    $results = mysqli_query($mysqli, "
		SELECT count(*) 
		FROM trainingmodule
		where trainingmodule.device_id = '$device_id'
    ");

    $mysqli_error = mysqli_error($mysqli);
    if ($mysqli_error) {
        $json_out["ERROR"] = $mysqli_error;
        ErrorExit(2);
    }

    $count = mysqli_fetch_row($results);
	$results->close();

    if ($count[0] == 0) {
        $status_id = 10;
		$json_out["authorized"] = "Y";
        // If device has no training modules, no need to check further
        // so exit the function.
        return $status_id;
    }

    // Check if user has completed the necessary training modules
    $results = mysqli_query($mysqli, "
		SELECT count(*)
		FROM trainingmodule
		INNER JOIN tm_enroll on trainingmodule.tm_id = tm_enroll.tm_id
		WHERE uta_id = '$uta_id' AND device_id = '$device_id'
    ");

    $mysql_error = mysqli_error($mysqli);
    if ($mysql_error) {
        $json_out["ERROR"] = $mysql_error;
        ErrorExit(2);
    }

	$count = mysqli_fetch_row($results);
	$results->close();
	
    if ($count[0] == 0) {
        $status_id = 2;
		$json_out["authorized"] = "N";
		$json_out ["ERROR"] = "Device: ".$device_id." requires training";
        return $status_id;
    } else {
        $status_id = 10;
		$json_out["authorized"] = "Y";
        return $status_id;
    }
}
?>