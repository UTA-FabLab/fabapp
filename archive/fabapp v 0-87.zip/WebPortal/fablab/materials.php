<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST");
header("Access-Control-Allow-Headers: Cache-Control, Origin, X-Requested-With, Content-Type, Accept, Key, X-Api-Key");

/*
 *  materials.php : Materials list interface
 *
 *  Michael Doran, Systems Librarian
 *  University of Texas at Arlington
 *	
 *	Arun Kalahasti, 
 *  version: 0.1 alpha (2016-05-20)
 *
*/

// Requests/replies via JSON data exchange
// =======================================
// 1) Get Materials By Device ID

require_once( __DIR__."/../connections/db_connect8.php");
include 'gatekeeper.php'; 
$json_out = array();

// Input posted with "Content-Type: application/json" header
$input_data = json_decode(file_get_contents('php://input'), true);
if (! ($input_data)) {
	$json_out["ERROR"] = "Unable to decode JSON message - check syntax";
	ErrorExit(1);
}
	
// Tell PHP what time zone before doing any date function foo 
date_default_timezone_set('America/Chicago');

// Extract message type from incoming JSON
$type      = $input_data["type"];
	
// Check the request type
if (strtolower($type) == "device_id") {
	$device_id = $input_data["device"];
	GetByDeviceID($device_id);
} else {
	$json_out["ERROR"] = "Unknown type: $type";
	ErrorExit(1);
}

	
	// Output JSON and exit
header("Content-Type: application/json");
echo json_encode($json_out);
exit(0);


////////////////////////////////////////////////////////////////
//                           Functions
////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////
//
//  Template 
//  

function Template ($arguments) {
	global $json_out;
	global $mysqli;
	
}

////////////////////////////////////////////////////////////////
//
//  GetByDeviceID 
//  

function GetByDeviceID ($device_id) {
	global $json_out;
	global $mysqli;
	
	CheckDeviceID($device_id);
	
	$result = mysqli_query($mysqli, "
		SELECT `materials`.`m_id`, `materials`.`m_name`, `materials`.`price`, `materials`.`unit`
		FROM `materials` 
		LEFT JOIN `device_materials`
		ON `device_materials`.`m_id` = `materials`.`m_id` 
		WHERE `dg_id` = (SELECT `devices`.`dg_id` FROM `devices` WHERE `devices`.`d_id` = $device_id)
		ORDER BY `m_name`;
    ");
	if ($mysqli->error) {
        $json_out["ERROR"] = $mysqli->error;
        ErrorExit(2);
    }
	
	while($row = $result->fetch_array(MYSQL_ASSOC)) {
            $json_out[] = $row;
    }
	
}

////////////////////////////////////////////////////////////////
//
//  CheckDeviceID 
//  

function CheckDeviceID ($device_id) {
	global $json_out;
	
	// Check for valid device_id value
    if (preg_match("/^\d{4}$/",$device_id) == 0) {
        $json_out["success"] = "N";
        $json_out["ERROR"] = "Invalid or missing device_id: $device_id";
        ErrorExit(1);
    }
	
}

////////////////////////////////////////////////////////////////
//
//  ErrorExit
//  Sends error message and quits 

function ErrorExit ($exit_status) {
	global $mysqli;
    global $json_out;
    header("Content-Type: application/json");
	$mysqli->close();
    echo json_encode($json_out);
    exit($exit_status);
}

?>