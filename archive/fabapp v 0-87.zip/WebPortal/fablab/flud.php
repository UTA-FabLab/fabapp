<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST");
header("Access-Control-Allow-Headers: Cache-Control, Origin, X-Requested-With, Content-Type, Accept, Key, X-Api-Key");

/*
 *  flud.php : Fab Lab User Data
 *
 *  Michael Doran, Systems Librarian
 *  University of Texas at Arlington
 *
 *  Jonathan Le, Super FabLabian
 *  Arun Kalahasti, Super FabLabian
 *	FabLab @ University of Texas at Arlington
 
 *  version: 0.88 beta (2016-09-22)
 *
*/

// Requests/replies via JSON data exchange
// =======================================
// 1) Power On Request -  OnTransaction
// 2) Power Off Notification - OffTransaction
// 3) Interaction Entry - StartTransaction
// 5) PrintTransaction 
// 6) End Request - EndTransaction

require_once( __DIR__."/../connections/db_connect8.php");
include 'gatekeeper.php'; 
$json_out = array();

/*
//Test Data
$input_data["type"] = "print";
$input_data["uta_id"] = "1000129288";
$input_data["device_id"] = "0021";
$input_data["m_id"] = "1";
$input_data["est_build_time"] = "00:00:01";
$input_data["p_id"] = 1;
*/

// Input posted with "Content-Type: application/json" header
$input_data = json_decode(file_get_contents('php://input'), true);
if (! ($input_data)) {
	$json_out["ERROR"] = "Unable to decode JSON message - check syntax";
	ErrorExit(1);
}

// Tell PHP what time zone before doing any date function foo 
date_default_timezone_set('America/Chicago');

// Extract message type from incoming JSON
$type = $input_data["type"];



// Check the request type
if (strtolower($type) == "utaid") {
	$uta_id = $input_data["number"];
	$device_id = $input_data["device"];
	OnTransaction($uta_id,$device_id);
} elseif (strtolower($type) == "rfid") {
	$uta_id = RFIDtoUTAID($input_data["number"]);
	$device_id = $input_data["device"];
	OnTransaction($uta_id,$device_id);
} elseif (strtolower($type) == "power_off") {
	$trans_id  = $input_data["trans_id"];
	$trans_end = $input_data["trans_end"];
	OffTransaction($trans_id,$trans_end);
}  elseif (strtolower($type) == "print") {
	$uta_id  = $input_data["uta_id"];
	$device_id = $input_data["device_id"];
	PrintTransaction ($uta_id,$device_id);
} elseif (strtolower($type) == "start") { 
	$trans_id  = $input_data["trans_id"];
	$status_id = 10; //powered on
	StartTransaction($trans_id,$status_id);
} elseif (strtolower($type) == "end") {
	$trans_id  = $input_data["trans_id"];
	EndTransaction ($trans_id);
} else {
	$json_out["ERROR"] = "Unknown type: $type";
	ErrorExit(1);
}

	
	// Output JSON and exit
header("Content-Type: application/json");
echo json_encode($json_out);
exit(0);


////////////////////////////////////////////////////////////////
//                           Functions
////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////
//
//  OnTransaction 
//  Checks to see if user is authorized to use a Fab Lab device

function OnTransaction ($uta_id,$device_id) {

	$status_id = IsAuthorized($uta_id,$device_id);
	CreateTransaction($uta_id,$device_id,$status_id);	
}

////////////////////////////////////////////////////////////////
//
//  PrintTransaction
//  Inserts entry into the 'transactions' & mats_used table

function PrintTransaction ($uta_id,$device_id) {
    global $json_out;
	global $mysqli;
	global $input_data;
	
	$print_json = array();
	
	
	//prevent print
	if( $result = $mysqli->query("
		SELECT * FROM `transactions` WHERE device_id = $device_id AND status_id < 12
	")){
		if( $result->num_rows > 0){
			$json_out["authorized"] = "N";
			$json_out["ERROR"] = "Can not start new print on this printer until previous ticket has been closed.";
			ErrorExit(0);
		}
	} else {
        $json_out["ERROR"] = $mysql_error;
        ErrorExit(2);
	}
	
	$auth_status = IsAuthorized($uta_id, $device_id);
	
	if ($auth_status < 10){
		ErrorExit(0);
	}
	
	$print_json["type"] = "start_ticket";
	$print_json["device_id"] = $device_id;
	
	$device_name_result = mysqli_query($mysqli, "
			SELECT  `device_desc` as device_name
			FROM  `devices` 
			WHERE  `device_id` =  $device_id;
		");
	
	$row = $device_name_result->fetch_array();
	
	if (!is_null($row["device_name"])){
		$print_json["device_name"] = $row["device_name"];
	}
	else{
		$json_out["m_name"] = "Not found";
	}
	$device_name_result->close();
	
	if ($input_data["m_id"]){
		
		$m_id = $input_data["m_id"];
		$material_name_result = mysqli_query($mysqli, "
			SELECT `materials`.`m_name`, `materials`.`price`, `materials`.`unit` FROM `materials` WHERE `materials`.`m_id` = $m_id;
		");
		
		$row = $material_name_result->fetch_array();
		
		if (!is_null($row["m_name"])){
			$json_out["m_name"] = $row["m_name"];
			$print_json["m_name"] = $row["m_name"];
			$print_json["est_cost"] = round($input_data["est_filament_used"]) * $row["price"];
			$filament_unit = $row["unit"];
			$print_json["est_material"] = round($input_data["est_filament_used"])." ".$filament_unit;
		}
		else{
			$json_out["m_name"] = "Not found";
		}
		$material_name_result->close();
	}
	
	if ($input_data["filename"]){
		
		$print_json["filename"] = $input_data["filename"];
		
	}
	
	if ($input_data["est_build_time"]){
		
		$est_build_time = $input_data["est_build_time"];
		$print_json["est_build_time"] = $est_build_time;
		$print_json["est_duration"] = $input_data["est_build_time"];
		
	}

	if ($input_data["p_id"]){
		
		$p_id = $input_data["p_id"];
		$print_json["p_id"] = $p_id;
		
	}
	
    $insert_result = mysqli_query($mysqli, "
			  INSERT INTO transactions 
				(`uta_id`,`device_id`,`t_start`,`status_id`,`purp_id`,`est_time`) 
			  VALUES
				('$uta_id','$device_id',CURRENT_TIMESTAMP,'$auth_status','$p_id','$est_build_time');
    ");
    $mysqli_error = mysqli_error($mysqli);
    if ($mysqli_error) {
			$json_out["ERROR"] = $mysqli_error;
			ErrorExit(2);
    } else {
        $trans_id = mysqli_insert_id($mysqli);
		if ($result = $mysqli->query("
			INSERT INTO mats_used 
				(`trans_id`,`m_id`,`status_id`) 
			  VALUES
				($trans_id, $m_id, $auth_status);
		")){
			$json_out["trans_id"]   = $trans_id;
			$json_out["status_id"] = $auth_status;
			$print_json["trans_id"]   = $trans_id;
		} else {
			$json_out["ERROR"] = $mysqli_error;
			ErrorExit(2);
		}
    }
	$json_out["PRINT_JSON"] = $print_json;
	$json_out["PRINT_RESPONSE"] = PrintReceipt($print_json);
	
}

////////////////////////////////////////////////////////////////
//
//  CreateTransaction
//  Inserts entry into the 'transactions' table

function CreateTransaction ($uta_id,$device_id,$status_id) {
    global $json_out;
	global $mysqli;

    $insert_result = mysqli_query($mysqli, "
      INSERT INTO transactions 
        (`uta_id`,`device_id`,`t_start`,`status_id`) 
      VALUES
        ('$uta_id','$device_id',CURRENT_TIMESTAMP,'$status_id');
    ");
    $mysqli_error = mysqli_error($mysqli);
    if ($mysqli_error) {
			$json_out["ERROR"] = $mysqli_error;
			ErrorExit(2);
    } else {
        $trans_id = mysqli_insert_id($mysqli);
        $json_out["trans_id"]   = $trans_id;
        $json_out["status_id"] = $status_id;
    }
}

////////////////////////////////////////////////////////////////
//
//  OffTransaction
//  Places an ending time to an entry in the 'transactions' table

function OffTransaction ($trans_id,$trans_end) {
    global $json_out;
	global $mysqli;
	$status_id = 14; //complete

    $json_out["trans_id"] = $trans_id;

    // Check for valid transaction ID value
    if (! (preg_match("/^\d*$/",$trans_id))) {
        $json_out["success"] = "N";
        $json_out["ERROR"] = "Invalid trans_id";
        ErrorExit(1);
    }

    // Check for valid trans_end value
    if (! (preg_match("/^Y$/",$trans_end))) {
        $json_out["success"] = "N";
        $json_out["ERROR"] = "Invalid trans_end value: $trans_end";
        ErrorExit(1);
    }
	
	
	//qualify if device is vinyl cutter or sewing machine
	if( $result = $mysqli->query("
		SELECT dg_name
		FROM devices
		LEFT JOIN device_group
		ON devices.dg_id = device_group.dg_id
		LEFT JOIN transactions
		ON transactions.device_id = devices.device_id
		WHERE trans_id = $trans_id;
		
	")){
		$row = $result->fetch_assoc();
		if ( $row["dg_name"] == "vinyl" || $row["dg_name"] == "sew" ) {
			$status_id = 11;
			// Do the update
			$update_result = mysqli_query($mysqli, "
				UPDATE transactions 
				SET t_end = CURRENT_TIMESTAMP, status_id = $status_id, 
					duration = SEC_TO_TIME (TIMESTAMPDIFF (SECOND,  t_start, CURRENT_TIMESTAMP))
				WHERE trans_id = $trans_id
			");
		} else {
			// Do the update
			$update_result = mysqli_query($mysqli, "
				UPDATE transactions 
				SET t_end = CURRENT_TIMESTAMP, status_id = $status_id, 
					duration = SEC_TO_TIME (TIMESTAMPDIFF (SECOND,  t_start, CURRENT_TIMESTAMP))
				WHERE trans_id = $trans_id
			");
		}
	} else {
        $json_out["success"] = "N";
        $json_out["ERROR"] = $mysqli->error;
        ErrorExit(2);
	}
    // Send back results
    $mysqli_error = mysqli_error($mysqli);
    if ($mysqli_error) {
        $json_out["success"] = "N";
        $json_out["ERROR"] = $mysqli_error;
        ErrorExit(2);
    } else if ($mysqli->affected_rows > 0) {
		//Checks Transaction Number 
        $json_out["success"] = "Y";
		$json_out["status_id"] = "8";
    } else {
		$json_out["success"] = "N";
		$json_out["ERROR"] = "Transaction number not found";
        ErrorExit(1);
	}
}

////////////////////////////////////////////////////////////////
//
//  StartTransaction
//  Updates an entry in the 'transactions' table
//  Checks if transaction already has end time stamp
function StartTransaction($trans_id,$status_id) {	
	global $json_out;
	global $mysqli;
	$json_out ["trans_id"] = $trans_id;

	// Check for valid transaction ID value
    if (! (preg_match("/^\d*$/",$trans_id))) {
        $json_out["success"] = "N";
        $json_out["ERROR"] = "Invalid transaction number";
        ErrorExit(1);
    }
	
    // Check for valid status_id value
    if (preg_match("/^\d{1}$/",$status_id) == 0) {
        $json_out["ERROR"] = "Invalid or missing status id value - $status_id";
        ErrorExit(1);
    }
	
	//Check if transaction has already ended
	$result = mysqli_query($mysqli, "
		SELECT t_end 
		FROM transactions
		WHERE trans_id = '$trans_id'
		LIMIT 1
    ");
	if ($mysqli->error) {
        $json_out["ERROR"] = $mysqli->error;
        ErrorExit(2);
    }
	$row = $result->fetch_array();
	if (!is_null($row["t_end"])){
        $json_out["success"] = "N";
        $json_out["ERROR"] = "Transaction has end time of:".$row["t_end"];
		ErrorExit(1);
	}
	$result->close();
	
	$result = mysqli_query($mysqli, "
		UPDATE transactions
		SET t_start = CURRENT_TIMESTAMP, status_id = $status_id
		WHERE trans_id = '$trans_id'
	");
	if ($mysqli->error) {
        $json_out["ERROR"] = $mysqli->error;
        ErrorExit(2);
    }
	//Checks Transaction Number
	if ($mysqli->affected_rows == 1) {
        $json_out["success"] = "Y";
		$json_out["status_id"] = $status_id;
	} else {
		$json_out["ERROR"] = "Transaction number was not found";
		ErrorExit(1);
	}
}

////////////////////////////////////////////////////////////////
//
//  EndTransaction
//  Ends an entry in the 'transactions' table

function EndTransaction ($trans_id) {
    global $json_out;
	global $mysqli;
	$json_out ["trans_id"] = $trans_id;
	$status_id = 6; //Moveable

    // Check for valid transaction ID value
    if (! (preg_match("/^\d*$/",$trans_id))) {
        $json_out["success"] = "N";
        $json_out["ERROR"] = "Invalid transaction number";
        ErrorExit(1);
    }

    // Check for valid status_id value
    if (preg_match("/^\d{1}$/",$status_id) == 0) {
        $json_out["success"] = "N";
        $json_out["ERROR"] = "Invalid or missing status_id: $status_id";
        ErrorExit(1);
    }

	/*	Legacy
    // Check for valid filament_amt amount
    if ($filament_amt && preg_match("/^\d{1,6}\.?\d*$/",$filament_amt) == 0) {
        $json_out["success"] = "N";
        $json_out["ERROR"] = "Invalid filament value: $filament_amt";
        ErrorExit(1);
    }
	*/
	
    // Do the update
    $update_result = mysqli_query($mysqli, "
        UPDATE transactions 
		SET t_end = CURRENT_TIMESTAMP, 
			status_id = $status_id,
			duration = SEC_TO_TIME (TIMESTAMPDIFF (SECOND,  t_start, CURRENT_TIMESTAMP))
        WHERE trans_id = $trans_id
    ");
	if ($mysqli->error) {
        $json_out["ERROR"] = $mysqli->error;
        ErrorExit(2);
    }
	//Checks Transaction Number 
	if ($mysqli->affected_rows == 1) {
        $json_out["success"] = "Y";
	} else {
		$json_out["ERROR"] = "Transaction number was not found";
		ErrorExit(1);
	}
}


////////////////////////////////////////////////////////////////
//
//  PrintReceipt
//  Prints a receipt given a JSON input

function PrintReceipt ($print_json) {
	
	$url = "https://fabapp-dev.uta.edu/api/php_printer/receipt.php";
	$content = json_encode($print_json);
	
	$options = array(
	  'http' => array(
		'method'  => 'POST',
		'content' => $content,
		'header'=>  "Content-Type: application/json\r\n" .
					"Accept: application/json\r\n"
		)
	);

	$context  = stream_context_create( $options );
	$result = file_get_contents( $url, false, $context );
	$response = json_decode( $result );
	return $response;
}


////////////////////////////////////////////////////////////////
//
//  RFIDtoUTAID
//  Matches RFID to a UTA ID

function RFIDtoUTAID ($rfid_no) {
	global $json_out;
    global $mysqli;

    //$result = $mysqli->query( "Select uta_id FROM rfid WHERE rfid_no = $rfid_no" );
    $result = mysqli_query($mysqli, "
      SELECT uta_id 
	  FROM rfid 
	  WHERE rfid_no = $rfid_no
    ");
    
    $mysql_error = mysqli_error($mysqli);
    if ($mysql_error) {
        $json_out["ERROR"] = $mysql_error;
        ErrorExit(2);
    }

    $row = $result->fetch_array(MYSQLI_NUM);;
    $uta_id = $row[0];

    if ($uta_id) {
        return($uta_id);
    } else {
        $json_out["ERROR"] = "No UTA ID match for RFID $rfid_no";
        ErrorExit(1);
    }
} 


////////////////////////////////////////////////////////////////
//
//  ErrorExit
//  Sends error message and quits 

function ErrorExit ($exit_status) {
	global $mysqli;
    global $json_out;
    header("Content-Type: application/json");
	$mysqli->close();
    echo json_encode($json_out);
    exit($exit_status);
}

?>