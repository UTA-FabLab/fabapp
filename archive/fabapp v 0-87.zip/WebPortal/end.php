<?php
require_once("connections/db_connect8.php");
session_start();
date_default_timezone_set('America/Chicago');
$message = $utaErr = $uta_id = "";

if( !isset($_SESSION["user_name"]) || ($_SESSION["time"] < time()) ) {
	header("Location:logout.php");	
}

//move sends type: regular
$dg_id = $_SESSION["dg_id"];
$trans_id = $_SESSION["trans_id"];

if ($_SESSION["type"] == "regular") {
	$status_id = 14; //Compete Status
	//check if transaction has a related material
	if ($result = $mysqli->query("
		SELECT *
		FROM mats_used
		WHERE trans_id = $trans_id
	")){
		$row_num = $result->num_rows;
	} else {
		$message = $mysqli->error;
	}
	
	if ($row_num){
		//Log ending time to transaction w/ mats
		if ($result = $mysqli->query("
			UPDATE `transactions`, `mats_used`
			SET `t_end` = CURRENT_TIMESTAMP, 
				transactions.status_id = $status_id, 
				mats_used.status_id = $status_id,
				duration = SEC_TO_TIME (TIMESTAMPDIFF (SECOND, t_start, CURRENT_TIMESTAMP))
			WHERE transactions.trans_id = $trans_id AND transactions.trans_id = mats_used.trans_id;
		")){
			if ($result = $mysqli->query("
			SELECT duration
			FROM transactions
			WHERE transactions.trans_id = $trans_id;
			")){
				$row = $result->fetch_assoc();
				$duration = $row["duration"];
				$message = "Ticket $trans_id has ended";
			} else 
				$message = $mysqli->error;
		} else {
			$message = $mysqli->error;
		}
	} else {
		//Log ending time to transaction w/o mats
		if ($result = $mysqli->query("
			UPDATE `transactions`
			SET `t_end` = CURRENT_TIMESTAMP, 
				transactions.status_id = $status_id,
				duration = SEC_TO_TIME (TIMESTAMPDIFF (SECOND, t_start, CURRENT_TIMESTAMP))
			WHERE transactions.trans_id = $trans_id;
		")){
			if ($result = $mysqli->query("
			SELECT duration
			FROM transactions
			WHERE transactions.trans_id = $trans_id;
			")){
				$row = $result->fetch_assoc();
				$duration = $row["duration"];
				$message = "Ticket $trans_id has ended";
			} else 
				$message = $mysqli->error;
		} else {
			$message = $mysqli->error;
		}
	}
}
?>
<html>
<head>
<link rel="shortcut icon" href="images/fa-icon.png?v=2" type="image/png">
	<title>FabLab End Transactions</title>
	<link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<?php include 'header.php'; ?>
<body>
	<table border="0" cellpadding="10" cellspacing="1" width="500" align="center">
		<tr class="tableheader">
			<td align="center" colspan="3"><h1><?php if($message!="") echo $message; ?></h1></td>
		</tr>
		<tr class="tablerow">
            <td align="Center">Device</td>
            <td><?php echo $_SESSION["device_desc"];?></td>
        </tr>
		<tr class="tablerow">
            <td align="Center">Mav ID</td>
            <td><?php echo $_SESSION["uta_id"];?></td>
        </tr>
		<tr class="tablerow">
            <td align="Center">Ticket #</td>
            <td><?php echo $_SESSION["trans_id"];?></td>
        </tr>
		<tr class="tablerow">
            <td align="Center">Duration</td>
            <td><?php echo $duration;?></td>
        </tr>
		<tr class="tableheader">
			<td align="center" colspan="3"><a href="home.php">Home</a></td>
		</tr>
	</table>
<script type="text/javascript">
setTimeout(function(){window.location = "home.php"}, 60000);
</script>
</body>
</html>