<?php
require_once("connections/db_connect8.php");
require_once("site_variables.php");
session_start();
date_default_timezone_set('America/Chicago');
$error = false;
$message = $deviceErr = $weightErr = $unit_used = $mErr = "";
unset($_SESSION["address"]);
unset($_SESSION["final_addy"]);

if(!isset($_SESSION["user_name"])) {
	header("Location:logout.php");	
} else {
	$_SESSION["time"] = (intval(time()) + $_SESSION["limit"]);
}

// Check Trans ID & direct traffic to their corresponding page
if (empty($_GET["trans_id"])){
	$error = true;
} else {
	$trans_id = $_GET["trans_id"];
	if (!(preg_match("/^\d*$/",$trans_id))) {
		$message = "Bad Ticket #".$trans_id;
		$error = true;
	} elseif ($result = $mysqli->query("
		SELECT devices.dg_id, dg_parent, transactions.device_id, device_desc, dg_name, uta_id, m_id
		FROM transactions
		LEFT JOIN devices
		ON transactions.device_id = devices.device_id
		LEFT JOIN device_group
		ON devices.dg_id = device_group.dg_id
		WHERE trans_id = '$trans_id'
	")){
		if ($result->num_rows == 0){
			$message = "Ticket Not found.";
			$error = true;
		} else {
			$row = $result->fetch_assoc();
			$device_id = $_SESSION["device_id"] = $row["device_id"];
			$_SESSION["device_desc"] = $row["device_desc"];
			$_SESSION["dg_id"] = $row["dg_id"];
			$m_id = $row["m_id"];
			$dg_name = $_SESSION["dg_name"] = $row["dg_name"];
			$_SESSION["dg_parent"] = $row["dg_parent"];
			$_SESSION["trans_id"] = $trans_id;
			$_SESSION["uta_id"] = $row["uta_id"];
			if ($_SESSION["dg_id"] == "5") {
				$_SESSION["type"] = "vinylpay";
				header("Location:pay.php");
			} elseif ($_SESSION["dg_id"] == "10") {
				$_SESSION["type"] = "sewpay";
				header("Location:pay.php");
			} elseif ($_SESSION["dg_parent"] != 1 && $_SESSION["dg_id"] != 1) {
				$_SESSION["type"] = "regular";
				header("Location:end.php");
			} else {
				//check if trans has an entry in mat_used
				if ( $result = $mysqli->query("
					SELECT *
					FROM mats_used
					WHERE trans_id = $trans_id;
				")){
					if ($result->num_rows == 0)
						$mats_check = true;
					else 
						$mats_check = false;
				}
			}
		}
	} else {
		$message = "Error MI6";
		$error = true;
	}
}

	
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$_SESSION["time"] = (intval(time()) + $_SESSION["limit"]);
	if ($dg_name == "uprint") {
			if (empty($_POST["status_id"])){
				$message = "Please select status";
			} elseif (!preg_match("/^\d{1,2}$/",$_POST["status_id"])) {
				$message = "Invalid Status";
			} elseif ($_POST["status_id"] == 14) {
				$status_id = 20; //set to Paid
				InsertObj($trans_id, $unit_used, $status_id, $dg_name);
			} else {
				$status_id = 20; //set to Paid
				Pay($trans_id, $unit_used, $_POST["status_id"], $m_id);
			}
	} elseif (!isset($_POST["unit_used"])) {
		$message = "Enter weight";
	} else {
		$unit_used = $_POST["unit_used"];
		if (empty($_POST["status_id"])){
			$message = "Please select status";
		} elseif (!preg_match("/^\d{1,2}$/",$_POST["status_id"])) {
			$message = "Invalid Status";
		} else {
			if ($mats_check) {
				// Check Material
				if (!isset($_POST["m_id"])){
					$mErr = "Select Material";
					$error = true;
				} elseif (preg_match("/^\d{1,4}$/", $_POST["m_id"]) && !$_POST["m_id"] == "none"){
					$mErr = "Invalid Material - ".$_POST["m_id"];
					$error = true;
				} else {
					$m_id = $_POST["m_id"];
					if ($m_id == "none")
						$m_id = "NULL";
				}
			} else {
				$m_id = "ignore";
			}
			
			switch($_POST["status_id"]) {
				case 14:
					$message = "Moved to Storage";
					InsertObj($trans_id, $unit_used, $_POST["status_id"], $m_id);
					break;
				case 12:
				case 20:
				case 21:
				case 22:
					$message = "Pay";
					Pay($trans_id, $unit_used, $_POST["status_id"], $m_id);
					break;
				default:
					$message = "Status Error.";
			}
		}
	}
}
	
function InsertObj($trans_id, $unit_used, $status_id, $m_id){
	global $message;
	global $mysqli;
	global $sv;
	$letter = array("A","B","C","D","E","F","G","H","I");
	
	// Check for valid transaction ID value
    if ( !(preg_match("/^\d*$/",$trans_id)) ) {
        $message = "Invalid Ticket #$trans_id";
		return;
	}
	
	if ($m_id != "uprint") {
		//Weight Check
		if ( !(preg_match("/^\d{0,4}\.{0,1}\d{0,2}$/",$unit_used)) ) {
			$message = "Invalid weight";
			return;
		} else {
			$unit_used = -$unit_used;
		}
	}
	
	//Check if transaction already has a home
	if ($result = $mysqli->query("
		SELECT address, t_end
		FROM transactions
		LEFT JOIN objbox
		ON transactions.trans_id = objbox.trans_id
		Where transactions.trans_id = $trans_id;
	")){
		//exit if so
		$row = $result->fetch_assoc();
		if ( isset($row["address"]) ){
			$address = $row["address"];
			$message = "Ticket - $trans_id already has an storage address, $address";
		return;
		} else 
			$t_end = $row["t_end"];
	}
	
	//Generate Address
	if ($result = $mysqli->query("SELECT address FROM objbox WHERE o_end IS NULL ORDER BY address ")) {
		$occupied = array();
		while ($row = $result->fetch_assoc()){
			array_push($occupied, $row["address"]);
		}
		$result->close();
		$address = rand(1,$sv["box_number"]).$letter[rand(0,$sv["letter"])];
		$test = TRUE;
		$i=0;
		if (count($occupied) > 0){
			while( $test == TRUE){//searches for a match
				if (strcmp($address,$occupied[$i]) == 0){
					$address = rand(1,$sv["box_number"]).$letter[rand(0,$sv["letter"])];
					$i = 0;
				}
				$i++;
				if($i == count($occupied))
					$test = False;
			}
		}
		$_SESSION["address"] = $address;
	} else {
        $message = $mysqli->error;
        return;
	}
	
	//check if mats_used exists
	if($m_id == "ignore"){
		
		if ( isset($t_end) ) {
			$string = "
				UPDATE `transactions`, `mats_used`
				SET mats_used.unit_used = $unit_used, mats_used.status_id = $status_id, transactions.status_id = $status_id
				WHERE transactions.trans_id = $trans_id AND transactions.trans_id = mats_used.trans_id;
			";
		} else {
			$string = "
				UPDATE `transactions`, `mats_used`
				SET `t_end` = CURRENT_TIMESTAMP, duration = SEC_TO_TIME (TIMESTAMPDIFF (SECOND,  t_start, CURRENT_TIMESTAMP)),
					mats_used.unit_used = $unit_used, mats_used.status_id = $status_id, transactions.status_id = $status_id
				WHERE transactions.trans_id = $trans_id AND transactions.trans_id = mats_used.trans_id;
			";
		}

		//Update Transaction with End time, Duration, and Status
		if ($mysqli->query($string)){
			//Log moving item into ObjManager
			if ($mysqli->query("
				INSERT INTO objbox (`trans_id`,`o_start`,`address`) 
				VALUES ('$trans_id',CURRENT_TIMESTAMP,'$address')
			")){
				header("Location:report.php");
			} else {
				$message = "objError".$mysqli->error;
				return;
			}
		}else {
			$message = "updateError".$mysqli->error;
			return;
		}
	} elseif ($m_id == "uprint"){
		
		if ( isset($t_end) ) {
			//Update Transactions Status
			$string = "
				UPDATE `transactions`
				SET transactions.status_id = $status_id
				WHERE transactions.trans_id = $trans_id ;
			";
		} else {
			//Update Transaction with End time, Duration, and Status
			$string = "
				UPDATE `transactions`
				SET `t_end` = CURRENT_TIMESTAMP, duration = SEC_TO_TIME (TIMESTAMPDIFF (SECOND,  t_start, CURRENT_TIMESTAMP)),
					transactions.status_id = $status_id
				WHERE transactions.trans_id = $trans_id ;
			";
		}
		
		
		if ($mysqli->query($string)){
			//Insert Mats Used
			if ($mysqli->query("
				UPDATE mats_used
				SET `status_id` = $status_id 
				WHERE trans_id = $trans_id;
			")){
				//Log moving item into ObjManager
				if ($mysqli->query("
					INSERT INTO objbox (`trans_id`,`o_start`,`address`) 
					VALUES ('$trans_id',CURRENT_TIMESTAMP,'$address')"
				)){
					header("Location:report.php");
				} else {
					$message =  $mysqli->error;
					return;
				}
			} else {
				$message =  $mysqli->error;
				return;
			}
		}else {
			$message =  $mysqli->error;
			return;
		}
	} else {
		if ( isset($t_end) ) {
			//Update Transactions Status
			$string = "
				UPDATE `transactions`
				SET transactions.status_id = $status_id
				WHERE transactions.trans_id = $trans_id;
			";
		} else {
			//Update Transaction with End time, Duration, and Status
			$string = "
				UPDATE `transactions`
				SET `t_end` = CURRENT_TIMESTAMP, duration = SEC_TO_TIME (TIMESTAMPDIFF (SECOND,  t_start, CURRENT_TIMESTAMP)),
					transactions.status_id = $status_id
				WHERE transactions.trans_id = $trans_id;
			";
		}
		//Update Transaction with End time, Duration, and Status
		if ($mysqli->query($string)){
			//Insert Mats Used
			if ($mysqli->query("
				INSERT INTO mats_used (`trans_id`,`m_id`,`unit_used`,`status_id`) 
				VALUES ($trans_id, $m_id, $unit_used, $status_id)"
			)){
				//Log moving item into ObjManager
				if ($mysqli->query("
					INSERT INTO objbox (`trans_id`,`o_start`,`address`) 
					VALUES ('$trans_id',CURRENT_TIMESTAMP,'$address')"
				)){
					header("Location:report.php");
				} else {
					$message =  "ObjManager Error ".$mysqli->error;
					return;
				}
			} else {
				$message =  "Mats_Used Error ".$mysqli->error;
				return;
			}
		}else {
			$message =  "UpdateTrans Error ".$mysqli->error;
			return;
		}
	}
}

function Pay($trans_id, $unit_used, $status_id, $m_id){
	global $message;
	global $mysqli;
	
	// Check for valid transaction ID value
    if ( !(preg_match("/^\d*$/",$trans_id)) ) {
        $message = "Invalid Ticket #$trans_id";
		return;
	}
	
	//Weight Check
	if ( !(preg_match("/^\d{0,4}\.{0,1}\d{0,2}$/",$unit_used)) ) {
		$message = "Invalid weight";
		return;
	} else {
		$unit_used = -$unit_used;
	}
	
	if ( $result = $mysqli->query("
		SELECT t_end
		FROM transactions
		Where trans_id = $trans_id;
	")){
		$row = $result->fetch_assoc();
		$t_end = $row["t_end"];
	} else {
		$message = "Move Error Pay76";
		return;
	}
	
	//pull down material price
	if ($m_id == "ignore") {
		if ( $result = $mysqli->query ("
				SELECT price, unit
				FROM materials
				LEFT JOIN mats_used
				ON materials.m_id = mats_used.m_id
				WHERE trans_id = $trans_id;
			")) {
				$row = $result->fetch_assoc();
				$price = $row["price"];
				$unit = $row["unit"];
				$result->close();
				if ($status_id == 12)
					$total = 0.00;
				else {
					$total = abs($unit_used) * floatval($price);
				}
				
				if ( isset($t_end) ) {
					// Update Transaction w/o end time
					$string = "
					UPDATE `transactions`, `mats_used`
					SET total = '$total', mats_used.unit_used = $unit_used, 
						mats_used.status_id = $status_id, transactions.status_id = $status_id
					WHERE transactions.trans_id = $trans_id and transactions.trans_id = mats_used.trans_id;
					";
				} else {
					//Update Transaction with End time, Duration, and Status
					$string = "
					UPDATE `transactions`, `mats_used`
					SET total = '$total', t_end = CURRENT_TIMESTAMP,
						duration = SEC_TO_TIME (TIMESTAMPDIFF (SECOND, t_start, CURRENT_TIMESTAMP)),
						mats_used.unit_used = $unit_used, mats_used.status_id = $status_id, transactions.status_id = $status_id
					WHERE transactions.trans_id = $trans_id and transactions.trans_id = mats_used.trans_id;
					";
				}
				if( $mysqli->query($string)){
					$_SESSION["type"] = "pay";
					$_SESSION["price"] = $price;
					$_SESSION["unit_used"] = abs($unit_used);
					$_SESSION["trans_id"] = $trans_id;
					$_SESSION["status_id"] = $status_id;
					$_SESSION["total"]= $total;
					header("Location:pay.php");
				} else {
					$message = $mysqli->error;
					return;
				}
		} else {
			$message = "Pull Price Error ".$mysqli->error;
		}
	} elseif ($m_id != "NULL") {  //no entry in mats_used table
		if ( $result = $mysqli->query ("
				SELECT price, unit
				FROM materials
				WHERE m_id = $m_id;
			")) {
				$row = $result->fetch_assoc();
				$price = $row["price"];
				$unit = $row["unit"];
				$result->close();
				if ($status_id == 12)
					$total = 0.00;
				else {
					$total = abs($unit_used) * floatval($price);
				}
				if ( isset($t_end) ) {
					// Update Transaction w/o end time
					$string = "
						UPDATE `transactions`
						SET total = '$total', transactions.status_id = $status_id
						WHERE transactions.trans_id = $trans_id;
					";
				} else {
					//Update Transaction with End time, Duration, and Status
					$string = "
						UPDATE `transactions`
						SET total = '$total', t_end = CURRENT_TIMESTAMP,
							duration = SEC_TO_TIME (TIMESTAMPDIFF (SECOND, t_start, CURRENT_TIMESTAMP)),
							transactions.status_id = $status_id
						WHERE transactions.trans_id = $trans_id;
					";
				}
				if( $mysqli->query($string)){
					if( $mysqli->query("
						INSERT INTO mats_used (`trans_id`,`m_id`,`unit_used`,`status_id`) 
						VALUES ($trans_id, $m_id, $unit_used, $status_id)
					")){
						$_SESSION["type"] = "pay";
						$_SESSION["price"] = $price;
						$_SESSION["unit_used"] = abs($unit_used);
						$_SESSION["trans_id"] = $trans_id;
						$_SESSION["status_id"] = $status_id;
						$_SESSION["total"]= $total;
						header("Location:pay.php");
					} else {
						$message = "M40 - ".$mysqli->error;
					}
				} else {
					$message = "M41 - ".$mysqli->error;
				}
		} else {
			$message = "M42 - ".$mysqli->error;
		}
	} else {
		if( $mysqli->query("
			UPDATE `transactions`
			SET total = '$total', t_end = CURRENT_TIMESTAMP,
				duration = SEC_TO_TIME (TIMESTAMPDIFF (SECOND, t_start, CURRENT_TIMESTAMP)),
				transactions.status_id = $status_id
			WHERE transactions.trans_id = $trans_id;
		")){
			$_SESSION["type"] = "regular";
			$_SESSION["trans_id"] = $trans_id;
			header("Location:end.php");
		}
	}
}
?>
<html>
<head>
<link rel="shortcut icon" href="images/fa-icon.png?v=2" type="image/png">
	<title>FabLab Move 3D Print</title>
	<link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<body>
	<?php include 'header.php';?>
	<div class="message"><?php if($message!="") { echo $message; } ?></div>
	<table border="0" cellpadding="10" cellspacing="1" width="500" align="center">
		<form id="moveform" name="moveform" method="post" action="" autocomplete="off" 
		onsubmit="return validateForm()">
		<tr class="tableheader">
			<td align="center" colspan="2"><h1>Move 3D Print</h1>
		</tr>
<?php if (!$error){?>
		<tr class="tablerow">
			<td align="right" id="t1">Ticket #</td>
			<td id="t2"><?php echo $trans_id; ?></td>
		</tr>
		<tr class="tablerow">
			<td align="right" id="t1">Device</td>
			<td id="t2"><?php echo $row["device_desc"]; ?></td>
		</tr>
		<?php //Display Mats for device
		if ( $mats_check ){ ?>
			<tr class="tablerow">
			<?php if($result = $mysqli->query("
				SELECT materials.m_id, m_name 
				FROM devices
				JOIN device_materials
				ON devices.dg_id = device_materials.dg_id
				JOIN materials
				ON materials.m_id = device_materials.m_id
				WHERE device_id = $device_id
				ORDER BY m_name ASC
			")){
				if ($result->num_rows > 0){ ?>
					<td align="Right">Material</td>
					<td><select name="m_id" id="m_id" tabindex="3">
						<option disabled hidden selected value="">Select</option>
					<?php while ($row = $result->fetch_assoc()) {
						echo("<option value='".$row["m_id"]."'>".$row["m_name"]."</option>");
					}
					$result->close();
				} else { ?>
					<td align="Right">Material</td>
					<td><select name="m_id" id="m_id" tabindex="3">
						<option selected value="none">None</option>
				<?php }
			} else {
				$message = "Error Getting Materials";
				$error = true;
			} ?>
			</select><div class="message"><?php echo $mErr;?></div></td>
			</tr><?php
		} ?>
		<?php if ($dg_name == "uprint") { ?> 		
			<tr class="tablerow">
				<td align="right">Print Status</td>
				<td>
					<select name="status_id" id="status_id">
						<option value="14" selected>Move to Storage</option>
						<option value="12">Pick Up Now</option>
					</select>
				</td>
			</tr>
		
		<?php } else { ?>
			<tr class="tablerow">
				<td align="right">Weight</td>
				<td><input type="number" name="unit_used" autocomplete="off" value="<?php echo $unit_used;?>" min="0" max="9999" step="1"> grams
				<div class="message"><?php echo $weightErr;?></div></td>
			</tr>		
			<tr class="tablerow">
				<td align="right">Print Status</td>
				<td>
					<select name="status_id" id="status_id">
						<option value="14" selected>Move to Storage</option>
						<option value="20">Pay Now</option>
						<option value="12">Failed</option>
						<option value="21">FabLab Account</option>
						<option value="22">Library Account</option>
					</select>
				</td>
			</tr>
		<?php } ?>
		<tr class="tableheader">
		<td align="center" colspan="2"><input type="submit" name="submit" id="submit" value="Submit"></td>
		</tr>
		</form>
<?php } ?>
	</table>
<script type="text/javascript">
setTimeout(function(){window.location.href ="home.php"}, 301000);
function validateForm() {
    var x = document.forms["moveform"]["unit_used"].value;
    if (x == null || x == "") {
        alert("Please Weigh Object");
        return false;
    }
    var y = document.forms["moveform"]["status_id"].value;
    if (y == null || y == "") {
        alert("Please select a Print Status");
        return false;
    }
<?php if ($mats_check) { ?>
		//Material Check
		var z = document.forms["moveform"]["m_id"].value;
		if (z == null || z == "") {
			alert("Please select a material");
			document.forms["moveform"]["m_id"].focus();
			return false;
		}
<?php } ?>
}
</script>
</body>
</html>