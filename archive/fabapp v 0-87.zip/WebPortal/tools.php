<?php
date_default_timezone_set('America/Chicago');
require_once("connections/db_connect8.php");
require_once("site_variables.php");
session_start();

//Pull uPrint material Price
if ($result = $mysqli->query("
	SELECT device_materials.m_id, price
	FROM materials
	LEFT JOIN device_materials
	ON materials.m_id = device_materials.m_id
	WHERE dg_id = 7
")){
	while( $row = $result->fetch_assoc() ) {
		$mats[$row["m_id"]] = $row["price"];
	}
		$result->close();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$serving = $_POST["serving"];
		if (preg_match("/^\d{1,3}$/",$serving) == 0) {
			echo ("Invalid Number");
		} else {
			if ($result = $mysqli->query("
			  UPDATE site_variables
			  SET value = $serving
			  WHERE site_variables.name = 'serving';
			")){
				header("Location:tools.php");
			} else {
				echo("SQL Error");
			}
		}
}
?>
<html>
<head>
<link rel="shortcut icon" href="images/FabLab_Favicon.png" type="image/png">
	<title>FabLab Tools</title>
	<link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<body>
<div class="main">
<?php 
if( isset($_SESSION["user_name"]) ) {
	include 'header.php';
?>
<form id="tform" name="tform" method="post" action="" onsubmit="return validateForm()"> 
	<table border="0" cellpadding="10" cellspacing="1" align="center">
		<tr>
			<td align="center" bgcolor="2b2b2b"><p style="color:white">Now Serving</p></td>
			<td>Enter Number</td>
		</tr>
		<tr>
			<td bgcolor="2b2b2b" ><p style="font-family: 'Raleway', sans-serif; color:red; font-size:800%;
			margin-top:-30px; margin-bottom:-20px"><?php echo $sv['serving'];?></p></td>
			<td><input type="text" name="serving" value="<?php echo $sv['serving'];?>" min="0" max="999"></td>
		</tr>
		<tr>
			<td></td>
        	<td align="right"><input type="submit" name="submit" value="Change Number" id="submitBtn"></td>
		</tr>
	</table>
</form>

<?php }?>
    <table border="0" cellpadding="10" cellspacing="1" width="500" align="center">
        <tr class="tableheader">
            <td align="center" colspan="2"><h1>Cost Estimation</h1></td>
        </tr>
		<tr class="tablerow" >
			<td align="Center"id="poly-1">PolyPrinter</td>
			<td id="poly-2"><input type="number" id="volume2" autocomplete="off" min="0" max="1000" step=".5" tabindex="2" onchange="polyPrinter()" onkeyup="polyPrinter()"> grams
			<div><div id="poly-3" style="float:left">$ 0.00 </div></div></td>
		</tr>
		<tr class="tablerow" >
			<td align="Center"id="vinyl-1">Vinyl</td>
			<td id="vinyl-2"><input type="number" id="volume3" autocomplete="off" min="0" max="1000" step=".5" tabindex="3" onchange="vinyl()" onkeyup="vinyl()"> inches
			<div><div id="vinyl-3" style="float:left">$ 0.00 </div></div></td>
		</tr>
		<tr class="tableheader">
			<td align="center" colspan=2>uPrint Cost<div id="uprint" style="float:right">$ 0.00 </div></td>
		</tr>
		<tr class="tablerow">
			<td align="center">Model Material</td>
			<td><input type="number" id="v1" autocomplete="off" min="0" max="1000" step=".01" tabindex="2" onchange="uPrint()" onkeyup="uPrint()"> in^3<div class="message"></div></td>
		</tr>
		<tr class="tablerow">
			<td align="center">Support Material</td>
			<td><input type="number" id="v2" autocomplete="off" min="0" max="1000" step=".01" tabindex="3" onchange="uPrint()" onkeyup="uPrint()"> in^3</td>
		</tr>
        <tr class="tableheader">
            <td align="center" colspan="2"><a href="home.php">Home</a>
        </tr>
    </table>
</div>
<script type="text/javascript">
setTimeout(function(){window.location.reload(1)}, 301000);

function resetForm() {
		document.getElementById("form").reset();
	}

function uPrint () {
	var conv_rate = <?php echo $sv['uprint_conv'];?>;
	var rate1 = <?php echo $mats['27'];?>;
	var rate2 = <?php echo $mats['32'];?>;
	var volume1 = document.getElementById("v1").value;
	var volume2 = document.getElementById("v2").value;
	var total = ( (volume1 * conv_rate * rate1)+(volume2 * conv_rate * rate2) ).toFixed(2);
	document.getElementById("uprint").innerHTML = "$ " + total;
}
function polyPrinter() {
	var rate = .05;
	var volume = document.getElementById("volume2").value;
	var total = (volume * rate).toFixed(2);
	document.getElementById("poly-3").innerHTML = "$ " + total;
}
function vinyl() {
	var rate = .25;
	var volume = document.getElementById("volume3").value;
	var total = (volume * rate).toFixed(2);
	document.getElementById("vinyl-3").innerHTML = "$ " + total;;
}
	
</script>
</body>
</html>