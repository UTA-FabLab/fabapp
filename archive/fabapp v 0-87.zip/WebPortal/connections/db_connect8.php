<?php

	// Connecting to mysql database with Role 8
	$mysqli = new mysqli('localhost', 'Fablabian', 'sbVaBEd3eW9dxmdb', 'fabapp') or die(mysql_error());
	
/*
$dbhost = "libwebmysqldev.ardclb.uta.edu";
$dbuser = "fabapp";
$dbpass = "SBmbe6MFwRDNFu5H";
$dbdatabase = "fabapp";
// Connecting to mysql database with Role 8
$mysqli = new mysqli($dbhost, $dbuser, $dbpass) or die(mysql_error());

// Selecing database
$mysqli->select_db($dbdatabase) or die(mysql_error());
*/
?>