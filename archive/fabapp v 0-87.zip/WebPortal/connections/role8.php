<?php
/*
 * Create, Update, & Read connection
*/
define('DB_USER', "Fablabian"); // db user
define('DB_PASSWORD', "sbVaBEd3eW9dxmdb"); // db password (mention your db password here)
define('DB_DATABASE', "fabapp"); // database name
define('DB_SERVER', "localhost"); // db server
?>