<?php

// Thermal printer connection settings

$tphost = "129.107.37.13";
$tpport = 9100;

?>