<?php
date_default_timezone_set('America/Chicago');
require_once("connections/db_connect8.php");
require_once("site_variables.php");
session_start();
$device_array = array();
unset($_SESSION["device_group"]);
unset($_SESSION["type"]);
unset($_SESSION["addy"]);
unset($_SESSION["final_addy"]);
if( !isset($_SESSION["user_name"]) || ($_SESSION["time"] < time()) ) {
	header("Location:logout.php");	
} else {
	$_SESSION["time"] = (intval(time()) + $_SESSION["limit"]);
}
?>
<html>
<head>
<link rel="shortcut icon" href="images/fa-icon.png?v=2" type="image/png">
	<title>FabLab Tickets</title>
	<link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<body>
<div align="center">
<?php include 'header.php';?>
</div>
	<table border="0" cellpadding="10" cellspacing="1" width="650" align="center">
		<tr class="tableheader">
			<td align="center" colspan="5"><h1>Device Status</h1>
			</td>
		</tr>
		<tr class="tablerow">
			<td align="right">Ticket</td>
			<td>Device</td>
			<td>Start Time</td>
			<td>Est Remaining Time</td>
			<td>Action</td>
		</tr>
		<?php if ($result = $mysqli->query("
				SELECT trans_id, device_desc, t_start, est_time, devices.dg_id, dg_parent, devices.device_id, multi_open, url
				FROM devices
				JOIN device_group
				ON devices.dg_id = device_group.dg_id
				LEFT JOIN (SELECT trans_id, t_start, t_end, est_time, device_id FROM transactions WHERE status_id < 12 ORDER BY trans_id DESC) as t 
				ON devices.device_id = t.device_id
				WHERE public_view = 'Y'
				GROUP BY `device_name`
				ORDER BY dg_id, `device_name`
			")){
				while ( $row = $result->fetch_assoc() ){ ?>
				<tr class="tablerow">
					<?php if($row["t_start"]) { ?>
						<td align="right"><?php echo $row["trans_id"]; ?></td>
						<?php if($row["url"]){ ?>
							<td><?php echo ("<a href=\"http://".$row["url"]."\">".$row["device_desc"]."</a>"); ?></td>
						<?php }else{ ?>
							<td><?php echo $row["device_desc"]; ?></td><?php }
						echo("<td>".date( 'M d g:i a',strtotime($row["t_start"]) )."</td>" );
						if( isset($row["est_time"]) ){
							echo("<td align=\"center\"><div id=\"est".$row["trans_id"]."\">".$row["est_time"]." </div></td>" ); 
						} else 
							echo("<td align=\"center\">-</td>"); 
						?>
						<td align="center">
							<button onclick="endTicket(<?php echo $row["trans_id"].",'".$row["device_desc"]."'"; ?>)">End Ticket</button>
						</td>
						<?php if ( isset($row["est_time"])) {
							$str_time = preg_replace("/^([\d]{1,2})\:([\d]{2})$/", "00:$1:$2", $row["est_time"]);
							sscanf($str_time, "%d:%d:%d", $hours, $minutes, $seconds);
							$time_seconds = $hours * 3600 + $minutes * 60 + $seconds;
							
							$time_seconds = $time_seconds - (time() - strtotime($row["t_start"]) ) + $sv["grace_period"];
							array_push($device_array, array($row["trans_id"], $time_seconds));
						}
					} else { ?>
						<td align="right"></td>
						<?php if($row["url"]){ ?>
							<td><?php echo ("<a href=\"http://".$row["url"]."\">".$row["device_desc"]."</a>"); ?></td>
						<?php }else{ ?>
							<td><?php echo $row["device_desc"]; ?></td><?php }?>
						<td align="center"> - </td>
						<td align="center"> - </td>
						<?php if($row["url"]){ ?>
							<td  align="center"><?php echo ("<a href=\"http://".$row["url"]."\">New Ticket</a>"); ?></td>
						<?php }else{ ?>
							<td align="center"><div id="est"><a href="create.php?<?php echo("device_id=".$row["device_id"])?>">New Ticket</a></div></td>
						<?php }?>

					<?php } ?>
				</tr>
					<?php
				}

			} 
		?>
	<tr class="tableheader">
		<td align="center" colspan="5">Found a bug? txt Jon Le 817-715-2708</td>
	</tr>
	</table>
</body>
<script type="text/javascript">
setTimeout(function(){window.location.reload(1)}, 301000);
function startTimer(duration, display) {
    var timer = duration, hours, minutes, seconds;
    setInterval(function () {
		if (timer > 0) {
			hours = parseInt(timer / 3600, 10);
			minutes = parseInt( (timer-(hours*3600))/60, 10);
			seconds = parseInt(timer % 60, 10);
			hours = hours < 10 ? hours : hours;
			minutes = minutes < 10 ? "0" + minutes : minutes;
			seconds = seconds < 10 ? "0" + seconds : seconds;
			
			display.textContent = hours + ":" + minutes + ":" + seconds;
			--timer;
		} else {
			hours = Math.abs(parseInt(timer / 3600, 10));
			minutes = Math.abs(parseInt( (timer+(hours*3600))/60, 10));
			seconds = Math.abs(parseInt(timer % 60, 10));
			hours = hours < 10 ? hours : hours;
			minutes = minutes < 10 ? "0" + minutes : minutes;
			seconds = seconds < 10 ? "0" + seconds : seconds;
			
			display.textContent = "- "+ hours + ":" + minutes + ":" + seconds;
			display.className="message";
			--timer;
		}
    }, 1000);
}
function endTicket(trans_id, device_desc) {
	var message = "Are you sure you want to end \n Ticket # ";
	message = message.concat(trans_id);
	message = message.concat(" on ");
	message = message.concat(device_desc);
    var answer = confirm(message);
	if (answer){
		var dest = "move.php?trans_id=";
		dest = dest.concat(trans_id);
		window.location.href = dest;
	}
}
window.onload = function () {
	<?php foreach ($device_array as $da) { ?>
		var time = <?php echo $da[1];?>;
		var display = document.getElementById('est<?php echo $da[0];?>');
		startTimer(time, display);
		
	<?php } ?>
};
</script>
</html>