<?php
session_start();
require_once("connections/db_connect8.php");
require_once("site_variables.php");
date_default_timezone_set('America/Chicago');
$message = $unit_used = $total = $mErr = "";

if( !isset($_SESSION["user_name"]) || ($_SESSION["time"] < time()) ) {
	header("Location:logout.php");	
} else {
	$_SESSION["time"] = (intval(time()) + $_SESSION["limit"]);
}
$dg_name = $_SESSION["dg_name"];
$trans_id = $_SESSION["trans_id"];

//check if trans has an entry in mat_used
if ( $result = $mysqli->query("
	SELECT *
	FROM mats_used
	WHERE trans_id = $trans_id;
")){
	if ($result->num_rows == 0)
		$mats_check = true;
	else {
		$mats_check = false;
		//pull down material price
		if ( $result = $mysqli->query ("		
				SELECT price, unit, transactions.status_id, t_start, SEC_TO_TIME(TIMESTAMPDIFF (SECOND, t_start, CURRENT_TIMESTAMP)) AS duration
				FROM materials
				LEFT JOIN mats_used
				ON materials.m_id = mats_used.m_id
				LEFT JOIN transactions
				ON mats_used.trans_id = transactions.trans_id
				WHERE mats_used.trans_id = $trans_id;
			")) {
				$row = $result->fetch_assoc();
				$duration = $row["duration"];
				$price = $row["price"];
				$t_start = $row["t_start"];
				$unit = $row["unit"];
				$result->close();
		} else {
			$message = $mysqli->error;
		}
	}
}

//get status Name
if ( isset($_SESSION["status_id"]) ) {
	$status_id = $_SESSION["status_id"];
	if ( $result = $mysqli->query ("
			SELECT msg
			FROM status
			WHERE status_id = $status_id;
		")) {
			$row = $result->fetch_assoc();
			$status_msg = $row["msg"];
			$result->close();
	} else {
		$message = $mysqli->error;
	}
}

//scrub before loading variables into functions
if ($_SERVER["REQUEST_METHOD"] == "POST" && $_SESSION["type"] != "pay") {
	$trans_id = $_SESSION["trans_id"];
	
	if ($_SESSION["type"] == "complete"){
		if (empty($_POST["unit_used"])){
			$message = "Please specify weight.";
		} else {
			$unit_used = $_POST["unit_used"];
			$uta_id = $_SESSION["uta_id"];
			if (empty($_POST["status_id"])){
				$message = "Please select status";
			} elseif (preg_match("/^\d{1,2}$/",$_POST["status_id"]) == 0) {
				$message = "Invalid Status";
			} else { 
				FinishPickUp($trans_id, $uta_id, $unit_used, $price, $_POST["status_id"]);
			}
		}
	} else {
		//type vinylpay
		if (empty($_POST["unit_used"])){
			$message = "Please specify length.";
		} else {
			$unit_used = $_POST["unit_used"];
			if (empty($_POST["status_id"])){
				$message = "Please select status";
			} elseif (preg_match("/^\d{1,2}$/",$_POST["status_id"]) == 0) {
				$message = "Invalid Status";
			} elseif ($mats_check) {
				if (!isset($_POST["m_id"])){
					$mErr = "Select Material";
				} elseif (preg_match("/^\d{1,4}$/", $_POST["m_id"]) && !$_POST["m_id"] == "none"){
					$mErr = "Invalid Material - ".$_POST["m_id"];
				} else {
					VinylPay2($trans_id, $_POST["status_id"], $unit_used, $_POST["m_id"]);
				}
			}else { 
				VinylPay($trans_id, $_POST["status_id"], $unit_used, $price);
			}
		}
	}	
}

function FinishPickUp($trans_id, $uta_id, $unit_used, $price, $status_id){
	global $mysqli;
	global $message;
	
	if ($status_id == 12) {
		$total = 0;
	} else {
		$total = $unit_used * floatval($_SESSION["price"]);
		$unit_used = -abs($unit_used);
	}
	
	if( $mysqli->query("
		UPDATE `transactions` 
		SET `total` = '$total', `unit_used` = '$unit_used', `status_id` = '$status_id'
		WHERE `trans_id` = $trans_id;
	")){
		//UPDATE  MATS_USED TABLE
		if( $mysqli->query("
			UPDATE `mats_used`
		")){
			
		} else {
			$message = "Update Materials Used Error";
			return;
		}
	} else {
		$message = "Update Transaction Error";
		return;
	}
	//update ObjBox Table
	if ($mysqli->query("
		UPDATE `objbox`
		SET `pickupid` = '$uta_id', `o_end` = CURRENT_TIMESTAMP
		WHERE `trans_id` = $trans_id;
	")){ } else {
		$message = "Update Object Manager Error";
		return;
	}
	unset($_SESSION["address"]);
	$_SESSION["type"] = "complete";
	$_SESSION["trans_id"] = $trans_id;
	$_SESSION["total"]= $total;
	header("Location:pay.php");
}
function VinylPay($trans_id, $status_id, $unit_used, $price){
	global $mysqli;
	global $message;
	
	if ($status_id == 12)
		$total = 0.00;
	else {
		$total = $unit_used * floatval($price);
		$unit_used = -abs($unit_used);
	}
	
	if( $mysqli->query("
		UPDATE `transactions`, `mats_used`
		SET total = '$total', t_end = CURRENT_TIMESTAMP,
			duration = SEC_TO_TIME (TIMESTAMPDIFF (SECOND, t_start, CURRENT_TIMESTAMP)),
			mats_used.unit_used = $unit_used, mats_used.status_id = $status_id, transactions.status_id = $status_id
		WHERE transactions.trans_id = $trans_id AND transactions.trans_id = mats_used.trans_id;
	")){
		$_SESSION["type"] = "pay";
		$_SESSION["unit_used"] = abs($unit_used);
		$_SESSION["trans_id"] = $trans_id;
		$_SESSION["status_id"] = $status_id;
		$_SESSION["total"]= $total;
		header("Location:pay.php");
	} else {
		$message = $mysqli->error;
		return;
	}
}
function VinylPay2($trans_id, $status_id, $unit_used, $m_id){
	global $mysqli;
	global $message;
	
	if ($status_id == 12) {
		$total = 0.00;
		$price = 0.00;
	} else {
		if ($result = $mysqli->query("
			SELECT price
			FROM materials
			WHERE m_id = $m_id;
		")){
			$row = $result->fetch_assoc();
			$price = $row["price"];
			$total = $unit_used * floatval($price);
			$unit_used = -abs($unit_used);
		}
	}
	if( $mysqli->query("
		UPDATE `transactions`
		SET total = '$total', t_end = CURRENT_TIMESTAMP,
			duration = SEC_TO_TIME (TIMESTAMPDIFF (SECOND, t_start, CURRENT_TIMESTAMP)),
			transactions.status_id = $status_id
		WHERE transactions.trans_id = $trans_id;
	")){
		if( $mysqli->query("
			INSERT INTO mats_used (`trans_id`,`m_id`,`unit_used`,`status_id`) 
			VALUES ($trans_id, $m_id, $unit_used, $status_id)
		")){
			$_SESSION["type"] = "pay";
			$_SESSION["price"] = $price;
			$_SESSION["status_id"] = $status_id;
			$_SESSION["total"] = $total;
			$_SESSION["trans_id"] = $trans_id;
			$_SESSION["unit_used"] = abs($unit_used);
			$_SESSION["unit"] = "inches";
			header("Location:pay.php");
		} else {
			$message = "P40 - ".$mysqli->error;
		}
	} else {
		$message = $mysqli->error;
		return;
	}
}
?>
<html>
<head>
<link rel="shortcut icon" href="images/fa-icon.png?v=2" type="image/png">
	<title>FabLab Complete</title>
	<link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<?php if( !strcmp($_SESSION["type"],"pay") ){ ?>
<body onload="calculate(<?php echo $price; ?>)">
<table border="0" cellpadding="10" cellspacing="1" width="500" align="center">
	<tr class="tableheader">
		<td align="center" colspan="2">
		<h1>Pay</h1>
		<div class="header"><?php if($message!="") { echo $message; } ?></div>
		</td>
	</tr>
	<?php if( strcmp($_SESSION["dg_name"],"uprint")==0 ){ //uPrint Qualifier?>
		<tr class="tablerow">
			<td align="right">Model Material's Rate</td>
			<td>$<?php echo $_SESSION["rate1"];?> * <?php echo $_SESSION["weight1"];?> grams</td>
		</tr>
		<tr class="tablerow">
			<td align="right">Model Support's Rate</td>
			<td>$<?php echo $_SESSION["rate2"];?> * <?php echo $_SESSION["weight2"];?> grams</td>
		</tr>
		<tr class="tablerow">
			<td align="right">UTA ID</td>
			<td><b><?php echo($_SESSION["uta_id"]);?></b></td>
		</tr>
		<tr class="tablerow">
			<td align="right">Total</td>
			<td><div name="total" id="total"><b><?php printf('$ %1.2f', $_SESSION["total"]); ?></b></div></td>
		</tr>
		<tr class="tablerow">
			<td align="right">Ticket Number</td>
			<td><b><?php echo $trans_id;?></b></td>
		</tr>
	<?php } else { ?>
		<tr class="tablerow">
			<td align="right">Material</td>
			<td>$<?php echo $price;?> * <?php echo ($_SESSION["unit_used"]." ".$unit);?></td>
		</tr>
		<tr class="tablerow">
			<td align="right">Status</td>
			<td><?php echo($status_msg);?></td>
		</tr>
		<tr class="tablerow">
			<td align="right">UTA ID</td>
			<td><?php echo($_SESSION["uta_id"]);?></td>
		</tr>
		<tr class="tablerow">
			<td align="right">Total</td>
			<td><div name="total" id="total"><?php printf('$ %1.2f', $_SESSION["total"]); ?></div></td>
		</tr>
		<tr class="tablerow">
			<td align="right">Ticket Number</td>
			<td><b><?php echo $trans_id;?></b></td>
		</tr>
	<?php } 
	//decide where to go based on Status Type 12-failed, 21+ accounts
	if ($status_id == 12 || $status_id > 20) { ?>
	<tr class="tableheader">
		<td align="center" colspan="2">
			<a href="home.php">Home</a>
		</td>
	</tr>
	<?php } else { ?>
	<tr class="tableheader">
		<td align="center" colspan="2">
			<button onclick="openWin()" id="csgold">Pay -> CSGold</button>
		</td>
	</tr>
	<?php } ?>
<?php } elseif ( !strcmp($_SESSION["type"],"vinylpay") ) {
	//Add-in ~ use multiple types of vinyl for one transaction ?>
<body>
<table border="0" cellpadding="10" cellspacing="1" width="500" align="center">
	<tr class="tableheader">
		<td align="center" colspan="2">
		<h1>Confirm Amount Used</h1>
		<div class="header"><?php if($message!="") { echo $message; } ?></div>
		</td>
	</tr>
	<form id="payform" name="payform" method="post" autocomplete="off" action="" onsubmit="submitBtn.disabled = true; return true;">
	<?php //Display Mats for device
	if ( $mats_check ){ ?>
		<tr class="tablerow">
		<?php if($result = $mysqli->query("
			SELECT materials.m_id, m_name, price
			FROM devices
			JOIN device_materials
			ON devices.dg_id = device_materials.dg_id
			JOIN materials
			ON materials.m_id = device_materials.m_id
			WHERE device_id = '0041'
			ORDER BY m_name ASC
		")){
			if ($result->num_rows > 0){ ?>
				<td align="Right">Material</td>
				<td align="Center"><select name="m_id" id="m_id" tabindex="3">
					<option disabled hidden selected value="">Select</option>
				<?php while ($row = $result->fetch_assoc()) {
					$price = $row["price"];
					echo("<option value='".$row["m_id"]."'>".$row["m_name"]."</option>");
				}
				$result->close();
			}
		} else {
			$message = "Error Getting Materials";
			$error = true;
		} ?>
		</select><div class="message"><?php echo $mErr;?></div></td>
		</tr>
		<tr class="tablerow">
			<td align="right">Material's Rate per inch</td>
			<td align="center">$<?php echo $price;?></td>
		</tr>
		<tr class="tablerow">
			<td align="right">Linear Length</td>
			<td align="center"><input type="number" name="unit_used" id="unit_used" autocomplete="off"
			value="<?php echo $unit_used;?>" min="0" max="1000" step="1" style="text-align: right" 
			onchange="calculate(<?php echo $price; ?>)" onkeyup="calculate(<?php echo $price; ?>)" autofocus> inches</td>
		</tr>
		<tr class="tablerow">
			<td align="right">Cost</td>
			<td align="center"><div name="total" id="total">$ 0.00</div></td>
		</tr>
		<tr class="tablerow">
			<td align="right">Print Status</td>
			<td align="Center">
				<select name="status_id" id="status_id"  onchange="calculate(<?php echo $price; ?>)">
					<option value="20">Pay Now</option>
					<option value="12">Failed</option>
					<option value="21">FabLab Account</option>
					<option value="22">Library Account</option>
				</select>
			</td>
		</tr>
	<?php } else { ?>
		<tr class="tablerow">
			<td align="right">Material's Rate per inch</td>
			<td align="center">$<?php echo $price;?></td>
		</tr>
		<tr class="tablerow">
			<td align="right">Linear Length</td>
			<td align="center"><input type="number" name="unit_used" id="unit_used" autocomplete="off"
			value="<?php echo $unit_used;?>" min="0" max="1000" step="1" style="text-align: right" 
			onchange="calculate(<?php echo $price; ?>)" onkeyup="calculate(<?php echo $price; ?>)" autofocus> inches</td>
		</tr>
		<tr class="tablerow">
			<td align="right">Cost</td>
			<td align="center"><div name="total" id="total">$ 0.00</div></td>
		</tr>
		<tr class="tablerow">
			<td align="right">Print Status</td>
			<td>
				<select name="status_id" id="status_id"  onchange="calculate(<?php echo $price; ?>)">
					<option value="20">Pay Now</option>
					<option value="12">Failed</option>
					<option value="21">FabLab Account</option>
					<option value="22">Library Account</option>
				</select>
			</td>
		</tr>
	<?php } ?>
	<tr class="tableheader">
		<td align="center" colspan="2"><input type="submit" name="submit" value="Next ->" id="submitBtn"></td>
	</tr>
	</form>
<?php } elseif ( !strcmp($_SESSION["type"],"sewpay") ) { 
	//Sewing Specific Payment & add duration readout!
	//$duration
	$str_time = preg_replace("/^([\d]{1,2})\:([\d]{2})$/", "00:$1:$2", $duration);
	sscanf($str_time, "%d:%d:%d", $hours, $minutes, $seconds);
	$time_hour = $hours + $minutes/60 + $seconds/3600;
	if( $time_hour < $sv["minTime"] )
		$unit_used = $sv["minTime"];
	else
		$unit_used = number_format( $time_hour, 2, ".", "");
?>
<body onload="calculate(<?php echo $price; ?>)">
<table border="0" cellpadding="10" cellspacing="1" width="500" align="center">
	<tr class="tableheader">
		<td align="center" colspan="2">
		<h1>Confirm Time Used</h1>
		<div class="header"><?php if($message!="") { echo $message; } ?></div>
		</td>
	</tr>
	<form id="payform" name="payform" method="post" autocomplete="off" action="" onsubmit="submitBtn.disabled = true; return true;">
	<tr class="tablerow">
		<td align="right">Sewing Time per Hour</td>
		<td align="center">$<?php echo $price;?></td>
	</tr>
	<tr class="tablerow">
		<td align="right">Start Time</td>
		<td align="center"><?php echo(date( 'M d g:i a',strtotime($t_start) ));?></td>
	</tr>
	<tr class="tablerow">
		<td align="right">Total Time</td>
		<td align="center"><input type="number" name="unit_used" id="unit_used" autocomplete="off"
		value="<?php echo $unit_used;?>" min="1" max="1000" step=".01" style="text-align: right" 
		onchange="calculate(<?php echo $price; ?>)" onkeyup="calculate(<?php echo $price; ?>)" autofocus> hours</td>
	</tr>
	<tr class="tablerow">
		<td align="right">Cost</td>
		<td align="center"><div name="total" id="total">$ 0.00</div></td>
	</tr>
	<tr class="tablerow">
		<td align="right">Print Status</td>
		<td>
			<select name="status_id" id="status_id"  onchange="calculate(<?php echo $price; ?>)">
				<option value="20">Pay Now</option>
				<option value="12">Failed</option>
				<option value="21">FabLab Account</option>
				<option value="22">Library Account</option>
			</select>
		</td>
	</tr>
	<tr class="tableheader">
		<td align="center" colspan="2"><input type="submit" name="submit" value="Next ->" id="submitBtn"></td>
	</tr>
	</form>
<?php } ?>

</table>
<script type="text/javascript">
var myWindow;
var openBoolean = false;
function openWin() {
	if (!openBoolean) {
    myWindow = window.open("https://csgoldweb.uta.edu/admin/quicktran/main.php", "myWindow", "width=650,height=500");
	document.getElementById("csgold").innerHTML = "Close CSGold -> Home";
	} else {
		var message = "Did you take payment and logout of CSGold? ";
		var answer = confirm(message);
		if (answer){
			myWindow.close();
			window.location.href = "home.php";
		}
	}
	openBoolean = !openBoolean;
}
function calculate (rate) {
	var status_id = document.getElementById("status_id").value;
	switch(status_id){
		case "12":
			document.getElementById("total").innerHTML = "$ 0.00";
			break;
		case "20":
		default :
			var weight = document.payform.unit_used.value;
			var total = (weight * rate).toFixed(2);
			var currency = "$ ";
			document.getElementById("total").innerHTML = currency.concat(total);
	}
}
</script>
</body>
</html>